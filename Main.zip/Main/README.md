# BloomWatch - Global Flowering Phenology Monitor

## NASA Space Apps Challenge 2025

**Team:** Nex Hunter  
**Location:** Itahari, Nepal  
**Challenge:** BloomWatch: An Earth Observation Application for Global Flowering Phenology

---

## 🌸 Project Overview

BloomWatch is a comprehensive web application that harnesses NASA Earth observations to create a dynamic visual tool for monitoring global flowering phenology. The application tracks vegetation changes, predicts blooming events, and advances solutions for monitoring, predicting, and managing vegetation worldwide.

### 🎯 Challenge Description

Witness the pulse of life across our planet! From season to season and year to year, Earth's vegetation is constantly changing, providing critical information on plant species, crops, seasonal effects, pollen sources, and changes in plant phenology (the relationship between seasonal changes and climate and biological phenomena in plants).

---

## ✨ Features

### 🌍 Global Monitoring
- **Interactive World Map**: Real-time visualization of blooming activity worldwide
- **Multiple Data Layers**: Bloom status, NDVI values, and satellite imagery
- **Location-based Filtering**: Filter by ecosystem type, bloom status, and NDVI range

### 📊 Data Analytics
- **Time Series Analysis**: Track vegetation trends over time
- **Seasonal Patterns**: Analyze blooming patterns across different seasons
- **Climate Correlation**: Understand relationships between weather and vegetation
- **Prediction Models**: AI-powered bloom probability forecasting

### 🛰️ NASA Integration
- **Real NASA API Integration**: Live data from NASA Earth observation satellites
- **MODIS Data**: Normalized Difference Vegetation Index (NDVI) monitoring
- **Landsat Imagery**: High-resolution satellite imagery
- **EPIC Images**: Earth Polychromatic Imaging Camera data
- **EONET Events**: Natural event monitoring

### 📱 User Experience
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **Personal Watchlist**: Save and monitor favorite locations
- **Real-time Notifications**: Alerts for bloom events and seasonal changes
- **Data Export**: Export analysis data for research purposes

---

## 🛠️ Technology Stack

### Backend
- **PHP 8.0+**: Server-side scripting and API development
- **SQLite**: Lightweight database for data storage
- **NASA APIs**: Direct integration with NASA's open data APIs

### Frontend
- **HTML5 & CSS3**: Modern web standards
- **Bootstrap 5**: Responsive UI framework
- **JavaScript (ES6+)**: Interactive functionality
- **Leaflet.js**: Interactive maps
- **Chart.js**: Data visualization and charts

### APIs & Data Sources
- **NASA APOD**: Astronomy Picture of the Day
- **NASA Earth Imagery**: Landsat satellite imagery
- **NASA EONET**: Earth Observatory Natural Event Tracker
- **NASA EPIC**: Earth Polychromatic Imaging Camera
- **MODIS**: Moderate Resolution Imaging Spectroradiometer
- **Earthdata GIBS**: Global Imagery Browse Services

---

## 🚀 Installation & Setup

### Prerequisites
- PHP 8.0 or higher
- Web server (Apache/Nginx) or PHP built-in server
- Modern web browser
- Internet connection for NASA API access

### Quick Start

1. **Clone the Repository**
   ```bash
   git clone https://github.com/your-repo/bloomwatch.git
   cd bloomwatch
   ```

2. **Setup Directory Structure**
   ```
   bloomwatch/
   ├── index.php                 # Main entry point
   ├── config/                   # Configuration files
   │   ├── database.php         # Database setup
   │   └── nasa_api.php         # NASA API configuration
   ├── pages/                   # Application pages
   ├── api/                     # API endpoints
   ├── assets/                  # Static assets
   │   ├── css/
   │   ├── js/
   │   └── images/
   ├── templates/               # HTML templates
   ├── includes/                # Helper functions
   └── data/                    # SQLite database (auto-created)
   ```

3. **Configure NASA API Key**
   
   The NASA API key is already configured in the application:
   ```
   API Key: pu7vlOsKIzfPc5riDrPxVuhCPYlM9HwlA5IPr8oO
   ```
   
   You can update it in `config/nasa_api.php` if needed:
   ```php
   const API_KEY = 'your-nasa-api-key-here';
   ```

4. **Start the Application**
   
   **Option A: PHP Built-in Server (Recommended for Development)**
   ```bash
   cd /path/to/bloomwatch
   php -S localhost:8000
   ```
   
   **Option B: Apache/Nginx**
   - Copy files to your web server document root
   - Ensure PHP is properly configured
   - Set proper permissions for the `data/` directory

5. **Access the Application**
   
   Open your web browser and navigate to:
   ```
   http://localhost:8000
   ```

### Database Setup

The application uses SQLite and will automatically:
- Create the database file at `data/bloomwatch.db`
- Set up all required tables
- Insert sample data for demonstration

No manual database setup is required!

---

## 📡 API Endpoints

### Main API Routes

- `GET /api/status` - API status and information
- `GET /api/locations` - Get all monitoring locations
- `GET /api/observations` - Get vegetation observations
- `GET /api/predictions` - Get bloom predictions
- `GET /api/nasa` - NASA data proxy endpoints

### NASA Data Endpoints

- `/api/nasa?endpoint=apod` - Astronomy Picture of the Day
- `/api/nasa?endpoint=earth_imagery&lat=X&lon=Y` - Earth imagery for coordinates
- `/api/nasa?endpoint=vegetation&lat=X&lon=Y` - Vegetation index data
- `/api/nasa?endpoint=events` - Natural events from EONET

### Example API Usage

```javascript
// Get current bloom status for all locations
fetch('/api/locations')
  .then(response => response.json())
  .then(data => console.log(data));

// Get vegetation data for Nepal
fetch('/api/nasa?endpoint=vegetation&lat=27.7172&lon=85.3240')
  .then(response => response.json())
  .then(data => console.log(data));
```

---

## 🌟 Key Features Breakdown

### 1. Dashboard
- Overview of global bloom activity
- Key statistics and metrics
- Recent observations and trends
- NASA Astronomy Picture of the Day integration

### 2. Global Map
- Interactive Leaflet map with bloom markers
- Real-time data visualization
- Multiple map layers (satellite, terrain, etc.)
- Location-based filtering and analysis

### 3. Data Explorer
- Comprehensive data browsing and filtering
- Export functionality (CSV, JSON)
- Advanced search and sorting
- Historical data analysis

### 4. Analytics
- Seasonal pattern analysis
- Climate correlation studies
- Machine learning predictions
- Statistical analysis tools

---

## 🔬 Data Sources & Methodology

### NASA APIs Used

1. **MODIS (Moderate Resolution Imaging Spectroradiometer)**
   - NDVI (Normalized Difference Vegetation Index) calculation
   - 250m-1km spatial resolution
   - Daily global coverage

2. **Landsat Program**
   - High-resolution multispectral imagery
   - 30m spatial resolution
   - 16-day repeat cycle

3. **EPIC (Earth Polychromatic Imaging Camera)**
   - Full-disk Earth imagery
   - Natural color and enhanced vegetation
   - Hourly imaging from L1 Lagrange point

4. **EONET (Earth Observatory Natural Event Tracker)**
   - Real-time natural event monitoring
   - Wildfires, storms, volcanoes, etc.
   - Global event categorization

### Bloom Detection Algorithm

The application uses a multi-factor approach to detect and predict blooming:

1. **NDVI Analysis**: Vegetation health indicator
   - NDVI > 0.6: High bloom probability
   - NDVI 0.4-0.6: Growing/pre-bloom stage
   - NDVI < 0.4: Dormant/low activity

2. **Seasonal Patterns**: Historical bloom timing analysis
3. **Climate Correlation**: Temperature, humidity, precipitation factors
4. **Machine Learning**: Predictive modeling for future events

---

## 🌍 Global Impact

### Applications

- **Agricultural Planning**: Optimize planting and harvesting schedules
- **Pollinator Conservation**: Track bloom timing for bee and butterfly habitats
- **Climate Research**: Study vegetation response to climate change
- **Tourism**: Predict peak bloom times for cherry blossoms, wildflowers
- **Ecosystem Management**: Monitor forest health and regeneration

### Target Users

- **Researchers**: Climate scientists, ecologists, botanists
- **Farmers**: Crop planning and management
- **Government Agencies**: Environmental monitoring and policy
- **Tourism Industry**: Seasonal event planning
- **Conservation Groups**: Habitat protection and restoration

---

## 🏆 NASA Space Apps Challenge Integration

### Challenge Requirements Met

✅ **Earth Observation Focus**: Utilizes multiple NASA Earth observation satellites  
✅ **Global Coverage**: Monitors vegetation worldwide  
✅ **Phenology Tracking**: Specifically targets flowering and bloom events  
✅ **Visual Interface**: Interactive maps and charts for data visualization  
✅ **Real-time Data**: Live NASA API integration  
✅ **Predictive Capability**: Bloom forecasting and trend analysis  
✅ **Open Source**: Built with open technologies and NASA open data  

### Innovation Highlights

- **Multi-API Integration**: Combines MODIS, Landsat, EPIC, and EONET data
- **Real-time Processing**: Live data feeds and automatic updates
- **User-Centric Design**: Intuitive interface for both experts and general public
- **Scalable Architecture**: Can handle global data volumes
- **Mobile-First**: Accessible on all devices and platforms

---

## 🤝 Contributing

We welcome contributions to BloomWatch! Here's how you can help:

### Development Setup

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Areas for Contribution

- **Algorithm Improvements**: Enhance bloom detection accuracy
- **New Data Sources**: Integrate additional NASA APIs
- **UI/UX Enhancements**: Improve user experience
- **Mobile App**: Native mobile application development
- **Documentation**: Improve guides and tutorials

---

## 📄 License

This project is open source and available under the MIT License. See the LICENSE file for more details.

---

## 🙏 Acknowledgments

- **NASA**: For providing open access to Earth observation data
- **NASA Space Apps Challenge**: For organizing this global hackathon
- **Open Source Community**: For the amazing tools and libraries used
- **Team Nex Hunter**: For dedication and hard work on this project

---

## 📞 Contact

**Team Nex Hunter**  
**Location**: Itahari, Nepal  
**Event**: NASA Space Apps Challenge 2025  

For questions, suggestions, or collaborations, please reach out through the NASA Space Apps Connect platform.

---

## 🔗 Links

- [NASA APIs](https://api.nasa.gov/)
- [NASA Worldview](https://worldview.earthdata.nasa.gov/)
- [NASA Earthdata](https://earthdata.nasa.gov/)
- [NASA Space Apps Challenge](https://www.spaceappschallenge.org/)

---

*Made with 💚 for our planet Earth during NASA Space Apps Challenge 2025* 🌍🛰️🌸