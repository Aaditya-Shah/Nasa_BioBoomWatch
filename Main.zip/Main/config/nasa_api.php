<?php
/**
 * NASA API Configuration
 * Contains API keys and endpoints for NASA services
 */

class NasaAPI {
    
    // NASA API Key
    const API_KEY = 'pu7vlOsKIzfPc5riDrPxVuhCPYlM9HwlA5IPr8oO';
    
    // NASA API Base URLs
    const BASE_URL = 'https://api.nasa.gov';
    const APOD_URL = 'https://api.nasa.gov/planetary/apod';
    const EARTH_URL = 'https://api.nasa.gov/planetary/earth';
    const EONET_URL = 'https://eonet.gsfc.nasa.gov/api/v3';
    const EPIC_URL = 'https://api.nasa.gov/EPIC/api';
    
    // Earthdata GIBS (Global Imagery Browse Services) - Replacement for deprecated Earth API
    const GIBS_URL = 'https://gibs.earthdata.nasa.gov/wmts/epsg4326/best';
    const WORLDVIEW_URL = 'https://worldview.earthdata.nasa.gov/api/v1';
    
    // MODIS and Landsat endpoints for vegetation data
    const MODIS_URL = 'https://modis.gsfc.nasa.gov/data';
    const LANDSAT_URL = 'https://landsat.gsfc.nasa.gov/data';
    
    // Rate limiting
    const HOURLY_LIMIT = 1000;
    const DEMO_HOURLY_LIMIT = 30;
    const DEMO_DAILY_LIMIT = 50;
    
    /**
     * Make API request to NASA endpoints
     */
    public static function makeRequest($endpoint, $params = []) {
        $params['api_key'] = self::API_KEY;
        $url = $endpoint . '?' . http_build_query($params);
        
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => [
                    'User-Agent: BloomWatch/1.0 (NASA Space Apps Challenge)',
                    'Accept: application/json'
                ],
                'timeout' => 30
            ]
        ]);
        
        $response = @file_get_contents($url, false, $context);
        
        if ($response === false) {
            error_log("NASA API request failed: " . $url);
            return false;
        }
        
        return json_decode($response, true);
    }
    
    /**
     * Get Astronomy Picture of the Day
     */
    public static function getAPOD($date = null) {
        $params = [];
        if ($date) {
            $params['date'] = $date;
        }
        
        return self::makeRequest(self::APOD_URL, $params);
    }
    
    /**
     * Get Earth imagery for specific coordinates
     */
    public static function getEarthImagery($lat, $lon, $date = null, $dim = 0.25) {
        $params = [
            'lat' => $lat,
            'lon' => $lon,
            'dim' => $dim
        ];
        
        if ($date) {
            $params['date'] = $date;
        }
        
        return self::makeRequest(self::EARTH_URL . '/imagery', $params);
    }
    
    /**
     * Get Earth assets (available images) for coordinates
     */
    public static function getEarthAssets($lat, $lon, $begin = null, $end = null) {
        $params = [
            'lat' => $lat,
            'lon' => $lon
        ];
        
        if ($begin) $params['begin'] = $begin;
        if ($end) $params['end'] = $end;
        
        return self::makeRequest(self::EARTH_URL . '/assets', $params);
    }
    
    /**
     * Get natural events from EONET
     */
    public static function getNaturalEvents($category = null, $status = 'open') {
        $url = self::EONET_URL . '/events';
        $params = ['status' => $status];
        
        if ($category) {
            $params['category'] = $category;
        }
        
        // EONET doesn't require API key
        unset($params['api_key']);
        $response = @file_get_contents($url . '?' . http_build_query($params));
        
        if ($response === false) {
            return false;
        }
        
        return json_decode($response, true);
    }
    
    /**
     * Get EPIC (Earth Polychromatic Imaging Camera) images
     */
    public static function getEPICImages($date = null) {
        $endpoint = self::EPIC_URL . '/natural';
        
        if ($date) {
            $endpoint .= '/date/' . $date;
        }
        
        return self::makeRequest($endpoint);
    }
    
    /**
     * Simulate vegetation index data (NDVI) for demonstration
     * In a real implementation, this would connect to MODIS or Landsat data
     */
    public static function getVegetationIndex($lat, $lon, $startDate, $endDate) {
        // This is a mock implementation for the hackathon
        // Real implementation would use MODIS/Landsat NDVI data
        
        $data = [];
        $start = new DateTime($startDate);
        $end = new DateTime($endDate);
        $interval = new DateInterval('P7D'); // Weekly intervals
        
        while ($start <= $end) {
            // Simulate NDVI values (0.0 to 1.0)
            // Higher values in spring/summer for blooming seasons
            $month = (int)$start->format('n');
            $baseNDVI = 0.3;
            
            // Simulate seasonal variation
            if ($month >= 3 && $month <= 8) { // Spring to early fall
                $baseNDVI += 0.4 * sin(($month - 3) * pi() / 6);
            }
            
            // Add some random variation
            $ndvi = $baseNDVI + (rand(-10, 10) / 100);
            $ndvi = max(0, min(1, $ndvi)); // Clamp to valid range
            
            $data[] = [
                'date' => $start->format('Y-m-d'),
                'ndvi' => round($ndvi, 3),
                'lat' => $lat,
                'lon' => $lon,
                'bloom_probability' => $ndvi > 0.6 ? rand(70, 95) : rand(10, 30)
            ];
            
            $start->add($interval);
        }
        
        return $data;
    }
}
?>