<?php
/**
 * Database Configuration
 * SQLite database setup for BloomWatch application
 */

class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        $this->connect();
        $this->createTables();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    private function connect() {
        $dbPath = __DIR__ . '/../data/bloomwatch.db';
        
        // Create data directory if it doesn't exist
        $dataDir = dirname($dbPath);
        if (!is_dir($dataDir)) {
            mkdir($dataDir, 0755, true);
        }
        
        try {
            $this->connection = new PDO('sqlite:' . $dbPath);
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die('Database connection failed: ' . $e->getMessage());
        }
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    private function createTables() {
        $sql = "
        -- Locations table for monitoring sites
        CREATE TABLE IF NOT EXISTS locations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(255) NOT NULL,
            latitude DECIMAL(10, 8) NOT NULL,
            longitude DECIMAL(11, 8) NOT NULL,
            country VARCHAR(100),
            region VARCHAR(100),
            ecosystem_type VARCHAR(100),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Vegetation observations table
        CREATE TABLE IF NOT EXISTS vegetation_observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            location_id INTEGER NOT NULL,
            observation_date DATE NOT NULL,
            ndvi_value DECIMAL(5, 3),
            evi_value DECIMAL(5, 3),
            bloom_status VARCHAR(50),
            bloom_intensity INTEGER DEFAULT 0,
            confidence_score DECIMAL(5, 3),
            data_source VARCHAR(100),
            satellite_image_url TEXT,
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (location_id) REFERENCES locations (id)
        );
        
        -- Bloom events table
        CREATE TABLE IF NOT EXISTS bloom_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            location_id INTEGER NOT NULL,
            species VARCHAR(255),
            bloom_start_date DATE,
            bloom_peak_date DATE,
            bloom_end_date DATE,
            bloom_duration INTEGER,
            intensity_level VARCHAR(50),
            weather_conditions TEXT,
            temperature_avg DECIMAL(5, 2),
            precipitation_mm DECIMAL(8, 2),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (location_id) REFERENCES locations (id)
        );
        
        -- API cache table
        CREATE TABLE IF NOT EXISTS api_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cache_key VARCHAR(255) UNIQUE NOT NULL,
            cache_data TEXT NOT NULL,
            expires_at DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        
        -- User favorites/watchlist
        CREATE TABLE IF NOT EXISTS user_watchlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_session VARCHAR(255) NOT NULL,
            location_id INTEGER NOT NULL,
            notification_enabled BOOLEAN DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (location_id) REFERENCES locations (id)
        );
        ";
        
        try {
            $this->connection->exec($sql);
            $this->insertSampleData();
        } catch (PDOException $e) {
            error_log('Database table creation failed: ' . $e->getMessage());
        }
    }
    
    private function insertSampleData() {
        // Check if sample data already exists
        $stmt = $this->connection->query("SELECT COUNT(*) as count FROM locations");
        $result = $stmt->fetch();
        
        if ($result['count'] > 0) {
            return; // Sample data already exists
        }
        
        // Insert sample locations around the world
        $sampleLocations = [
            ['Nepal Cherry Valley', 27.7172, 85.3240, 'Nepal', 'Kathmandu Valley', 'Temperate Forest'],
            ['California Central Valley', 36.7783, -119.4179, 'USA', 'California', 'Agricultural'],
            ['Amazon Rainforest', -3.4653, -62.2159, 'Brazil', 'Amazonas', 'Tropical Rainforest'],
            ['Sahara Desert Edge', 16.0544, 8.0751, 'Niger', 'Sahel', 'Semi-arid'],
            ['European Alps', 46.5197, 9.7307, 'Switzerland', 'Alps', 'Alpine'],
            ['Australian Outback', -25.2744, 133.7751, 'Australia', 'Northern Territory', 'Arid'],
            ['Japanese Cherry Regions', 35.6762, 139.6503, 'Japan', 'Honshu', 'Temperate'],
            ['Indian Western Ghats', 11.1271, 76.0266, 'India', 'Kerala', 'Tropical Forest'],
            ['African Savanna', -1.2921, 36.8219, 'Kenya', 'Rift Valley', 'Savanna'],
            ['Canadian Boreal Forest', 54.7267, -113.3011, 'Canada', 'Alberta', 'Boreal Forest']
        ];
        
        $stmt = $this->connection->prepare("
            INSERT INTO locations (name, latitude, longitude, country, region, ecosystem_type) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        foreach ($sampleLocations as $location) {
            $stmt->execute($location);
        }
        
        // Insert some sample vegetation observations
        $this->insertSampleObservations();
    }
    
    private function insertSampleObservations() {
        $stmt = $this->connection->prepare("
            INSERT INTO vegetation_observations 
            (location_id, observation_date, ndvi_value, bloom_status, bloom_intensity, confidence_score, data_source) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        // Generate sample data for the past 6 months
        $startDate = new DateTime('-6 months');
        $endDate = new DateTime();
        $interval = new DateInterval('P7D'); // Weekly
        
        for ($locationId = 1; $locationId <= 10; $locationId++) {
            $currentDate = clone $startDate;
            
            while ($currentDate <= $endDate) {
                $ndvi = rand(20, 85) / 100; // Random NDVI between 0.2 and 0.85
                $bloomStatus = $ndvi > 0.6 ? 'blooming' : ($ndvi > 0.4 ? 'growing' : 'dormant');
                $bloomIntensity = $ndvi > 0.6 ? rand(60, 100) : rand(0, 40);
                $confidence = rand(75, 95) / 100;
                
                $stmt->execute([
                    $locationId,
                    $currentDate->format('Y-m-d'),
                    $ndvi,
                    $bloomStatus,
                    $bloomIntensity,
                    $confidence,
                    'NASA_MODIS'
                ]);
                
                $currentDate->add($interval);
            }
        }
    }
}
?>