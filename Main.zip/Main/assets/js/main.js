/**
 * BloomWatch - Main JavaScript Functions
 */

// Global variables
let globalMap;
let currentUser = null;
let apiBaseUrl = '/api';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Check API status
    checkAPIStatus();
    
    // Initialize user session
    initializeUserSession();
    
    // Load user preferences
    loadUserPreferences();
    
    // Add event listeners
    addEventListeners();
    
    // Start periodic updates
    startPeriodicUpdates();
}

function checkAPIStatus() {
    fetch('/api/status')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'online') {
                updateAPIStatus('connected', 'success');
            } else {
                updateAPIStatus('offline', 'danger');
            }
        })
        .catch(error => {
            console.error('API status check failed:', error);
            updateAPIStatus('error', 'danger');
        });
}

function updateAPIStatus(status, type) {
    const statusElement = document.getElementById('api-status');
    if (statusElement) {
        statusElement.textContent = `API ${status}`;
        statusElement.className = `badge bg-${type}`;
    }
}

function initializeUserSession() {
    // Generate or retrieve user session ID
    let userId = localStorage.getItem('bloomwatch_user_id');
    if (!userId) {
        userId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('bloomwatch_user_id', userId);
    }
    currentUser = userId;
}

function loadUserPreferences() {
    const preferences = localStorage.getItem('bloomwatch_preferences');
    if (preferences) {
        try {
            const prefs = JSON.parse(preferences);
            applyUserPreferences(prefs);
        } catch (error) {
            console.error('Error loading user preferences:', error);
        }
    }
}

function applyUserPreferences(preferences) {
    // Apply temperature unit
    if (preferences.temperatureUnit) {
        // Update temperature displays
        updateTemperatureUnit(preferences.temperatureUnit);
    }
    
    // Apply theme preferences
    if (preferences.theme && preferences.theme === 'dark') {
        document.body.classList.add('dark-theme');
    }
    
    // Apply map preferences
    if (preferences.defaultMapView) {
        // Set default map view when maps are initialized
        window.defaultMapView = preferences.defaultMapView;
    }
}

function addEventListeners() {
    // Add click handlers for dynamic content
    document.addEventListener('click', handleDynamicClicks);
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);
    
    // Add window resize handler
    window.addEventListener('resize', handleWindowResize);
    
    // Add online/offline handlers
    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOfflineStatus);
}

function handleDynamicClicks(event) {
    const target = event.target;
    
    // Handle watchlist buttons
    if (target.classList.contains('watchlist-btn') || target.closest('.watchlist-btn')) {
        const locationId = target.dataset.locationId || target.closest('[data-location-id]').dataset.locationId;
        if (locationId) {
            toggleWatchlist(locationId);
        }
    }
    
    // Handle location detail buttons
    if (target.classList.contains('location-detail-btn') || target.closest('.location-detail-btn')) {
        const locationId = target.dataset.locationId || target.closest('[data-location-id]').dataset.locationId;
        if (locationId) {
            showLocationDetails(locationId);
        }
    }
    
    // Handle NASA imagery buttons
    if (target.classList.contains('nasa-imagery-btn') || target.closest('.nasa-imagery-btn')) {
        const lat = target.dataset.lat || target.closest('[data-lat]').dataset.lat;
        const lon = target.dataset.lon || target.closest('[data-lon]').dataset.lon;
        if (lat && lon) {
            openNASAImagery(lat, lon);
        }
    }
}

function handleKeyboardShortcuts(event) {
    // Ctrl/Cmd + K for search
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        focusSearch();
    }
    
    // Escape to close modals
    if (event.key === 'Escape') {
        closeTopModal();
    }
    
    // F5 to refresh data
    if (event.key === 'F5' && event.ctrlKey) {
        event.preventDefault();
        refreshApplicationData();
    }
}

function handleWindowResize() {
    // Resize maps if they exist
    if (typeof globalMap !== 'undefined' && globalMap) {
        setTimeout(() => {
            globalMap.invalidateSize();
        }, 100);
    }
    
    // Resize charts
    if (typeof Chart !== 'undefined') {
        Chart.helpers.each(Chart.instances, (instance) => {
            instance.resize();
        });
    }
}

function handleOnlineStatus() {
    showNotification('Connection restored', 'success');
    updateAPIStatus('connected', 'success');
    // Retry failed requests
    retryFailedRequests();
}

function handleOfflineStatus() {
    showNotification('Connection lost. Some features may not work.', 'warning');
    updateAPIStatus('offline', 'warning');
}

function startPeriodicUpdates() {
    // Update data every 5 minutes
    setInterval(() => {
        if (navigator.onLine) {
            refreshRealtimeData();
        }
    }, 5 * 60 * 1000);
    
    // Clean up expired cache every hour
    setInterval(() => {
        cleanLocalCache();
    }, 60 * 60 * 1000);
}

function refreshRealtimeData() {
    // Refresh current page data silently
    const currentPage = getCurrentPage();
    
    switch (currentPage) {
        case 'dashboard':
            refreshDashboardData();
            break;
        case 'map':
            refreshMapData();
            break;
        case 'data':
            refreshDataExplorerData();
            break;
        case 'analytics':
            refreshAnalyticsData();
            break;
    }
}

function getCurrentPage() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('page') || 'dashboard';
}

// Utility Functions

function showNotification(message, type = 'info', duration = 5000) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 80px; right: 20px; z-index: 9999; min-width: 300px; max-width: 400px;';
    
    alertDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-${getNotificationIcon(type)} me-2"></i>
            <div class="flex-grow-1">${message}</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto-dismiss
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, duration);
    
    // Add click to dismiss
    alertDiv.querySelector('.btn-close').addEventListener('click', () => {
        alertDiv.remove();
    });
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'check-circle';
        case 'danger': case 'error': return 'exclamation-circle';
        case 'warning': return 'exclamation-triangle';
        case 'info': return 'info-circle';
        default: return 'bell';
    }
}

function showLoading(element) {
    if (typeof element === 'string') {
        element = document.getElementById(element);
    }
    
    if (element) {
        element.innerHTML = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2 text-muted">Loading data...</p>
            </div>
        `;
    }
}

function hideLoading(element) {
    if (typeof element === 'string') {
        element = document.getElementById(element);
    }
    
    if (element && element.querySelector('.spinner-border')) {
        element.innerHTML = '';
    }
}

// API Helper Functions

async function apiRequest(endpoint, options = {}) {
    const url = apiBaseUrl + endpoint;
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'X-User-ID': currentUser
        }
    };
    
    const finalOptions = { ...defaultOptions, ...options };
    
    try {
        const response = await fetch(url, finalOptions);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API request failed:', error);
        
        // Store failed request for retry
        storeFailedRequest(url, finalOptions);
        
        throw error;
    }
}

function storeFailedRequest(url, options) {
    const failedRequests = JSON.parse(localStorage.getItem('failed_requests') || '[]');
    failedRequests.push({
        url,
        options,
        timestamp: Date.now()
    });
    
    // Keep only last 10 failed requests
    if (failedRequests.length > 10) {
        failedRequests.splice(0, failedRequests.length - 10);
    }
    
    localStorage.setItem('failed_requests', JSON.stringify(failedRequests));
}

async function retryFailedRequests() {
    const failedRequests = JSON.parse(localStorage.getItem('failed_requests') || '[]');
    
    if (failedRequests.length === 0) return;
    
    for (const request of failedRequests) {
        try {
            await fetch(request.url, request.options);
        } catch (error) {
            console.error('Retry failed for:', request.url, error);
        }
    }
    
    // Clear failed requests after retry attempt
    localStorage.removeItem('failed_requests');
}

// Watchlist Functions

async function toggleWatchlist(locationId) {
    try {
        const isInWatchlist = await checkWatchlistStatus(locationId);
        const action = isInWatchlist ? 'remove' : 'add';
        
        const response = await apiRequest('/watchlist', {
            method: 'POST',
            body: JSON.stringify({
                action: action,
                location_id: parseInt(locationId)
            })
        });
        
        if (response.success) {
            showNotification(response.message, 'success');
            updateWatchlistUI(locationId, action === 'add');
        } else {
            showNotification(response.message || 'Error updating watchlist', 'danger');
        }
    } catch (error) {
        console.error('Watchlist toggle error:', error);
        showNotification('Error updating watchlist', 'danger');
    }
}

async function checkWatchlistStatus(locationId) {
    try {
        const watchlist = await apiRequest('/watchlist');
        return watchlist.some(item => item.id === parseInt(locationId));
    } catch (error) {
        console.error('Error checking watchlist status:', error);
        return false;
    }
}

function updateWatchlistUI(locationId, isInWatchlist) {
    const buttons = document.querySelectorAll(`[data-location-id="${locationId}"] .watchlist-btn`);
    
    buttons.forEach(button => {
        const icon = button.querySelector('i');
        if (isInWatchlist) {
            button.classList.remove('btn-outline-danger');
            button.classList.add('btn-danger');
            if (icon) icon.classList.add('fas');
            if (icon) icon.classList.remove('far');
        } else {
            button.classList.remove('btn-danger');
            button.classList.add('btn-outline-danger');
            if (icon) icon.classList.remove('fas');
            if (icon) icon.classList.add('far');
        }
    });
}

// Location Functions

async function showLocationDetails(locationId) {
    try {
        showLoading('locationDetailsModal');
        
        const data = await apiRequest(`/location?id=${locationId}&history=true`);
        
        // Update modal content
        updateLocationDetailsModal(data);
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('locationDetailsModal'));
        modal.show();
        
    } catch (error) {
        console.error('Error loading location details:', error);
        showNotification('Error loading location details', 'danger');
    }
}

function updateLocationDetailsModal(data) {
    // Implementation would update modal content with location data
    console.log('Location details:', data);
}

// NASA Imagery Functions

function openNASAImagery(lat, lon, date = null) {
    const dateParam = date || new Date().toISOString().split('T')[0];
    const url = `https://worldview.earthdata.nasa.gov/?v=${lon-2},${lat-2},${lon+2},${lat+2}&t=${dateParam}&l=MODIS_Terra_CorrectedReflectance_TrueColor`;
    
    window.open(url, '_blank', 'width=1200,height=800');
}

// Cache Management

function cleanLocalCache() {
    const cacheKeys = Object.keys(localStorage);
    const now = Date.now();
    
    cacheKeys.forEach(key => {
        if (key.startsWith('cache_')) {
            try {
                const cacheData = JSON.parse(localStorage.getItem(key));
                if (cacheData.expires && cacheData.expires < now) {
                    localStorage.removeItem(key);
                }
            } catch (error) {
                // Remove invalid cache entries
                localStorage.removeItem(key);
            }
        }
    });
}

function setCacheData(key, data, ttl = 3600000) { // Default 1 hour
    const cacheData = {
        data: data,
        expires: Date.now() + ttl,
        created: Date.now()
    };
    
    localStorage.setItem(`cache_${key}`, JSON.stringify(cacheData));
}

function getCacheData(key) {
    try {
        const cacheData = JSON.parse(localStorage.getItem(`cache_${key}`));
        
        if (cacheData && cacheData.expires > Date.now()) {
            return cacheData.data;
        }
        
        // Remove expired cache
        localStorage.removeItem(`cache_${key}`);
        return null;
    } catch (error) {
        localStorage.removeItem(`cache_${key}`);
        return null;
    }
}

// Data Refresh Functions

async function refreshApplicationData() {
    showNotification('Refreshing application data...', 'info');
    
    try {
        await apiRequest('/refresh_data', { method: 'POST' });
        showNotification('Data refreshed successfully!', 'success');
        
        // Reload current page
        setTimeout(() => {
            window.location.reload();
        }, 2000);
        
    } catch (error) {
        console.error('Data refresh error:', error);
        showNotification('Error refreshing data', 'danger');
    }
}

async function refreshDashboardData() {
    // Implement dashboard-specific refresh
    console.log('Refreshing dashboard data...');
}

async function refreshMapData() {
    // Implement map-specific refresh
    console.log('Refreshing map data...');
}

async function refreshDataExplorerData() {
    // Implement data explorer-specific refresh
    console.log('Refreshing data explorer...');
}

async function refreshAnalyticsData() {
    // Implement analytics-specific refresh
    console.log('Refreshing analytics data...');
}

// Utility Functions

function focusSearch() {
    const searchInput = document.querySelector('input[type="search"], .search-input');
    if (searchInput) {
        searchInput.focus();
    }
}

function closeTopModal() {
    const modals = document.querySelectorAll('.modal.show');
    if (modals.length > 0) {
        const topModal = modals[modals.length - 1];
        const modal = bootstrap.Modal.getInstance(topModal);
        if (modal) {
            modal.hide();
        }
    }
}

function updateTemperatureUnit(unit) {
    const tempElements = document.querySelectorAll('.temperature');
    
    tempElements.forEach(element => {
        const celsius = parseFloat(element.dataset.celsius);
        if (!isNaN(celsius)) {
            if (unit === 'fahrenheit') {
                const fahrenheit = (celsius * 9/5) + 32;
                element.textContent = `${fahrenheit.toFixed(1)}°F`;
            } else {
                element.textContent = `${celsius.toFixed(1)}°C`;
            }
        }
    });
}

// Export functions for global use
window.BloomWatch = {
    showNotification,
    toggleWatchlist,
    showLocationDetails,
    openNASAImagery,
    refreshApplicationData,
    apiRequest
};