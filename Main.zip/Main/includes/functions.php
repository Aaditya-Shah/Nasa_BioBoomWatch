<?php
/**
 * Helper functions for BloomWatch application
 */

/**
 * Sanitize input data
 */
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Format date for display
 */
function formatDate($date, $format = 'M d, Y') {
    return date($format, strtotime($date));
}

/**
 * Get bloom status color
 */
function getBloomStatusColor($status) {
    switch (strtolower($status)) {
        case 'blooming':
            return '#ff6b6b';
        case 'growing':
            return '#4ecdc4';
        case 'dormant':
            return '#95a5a6';
        default:
            return '#bdc3c7';
    }
}

/**
 * Get bloom intensity color gradient
 */
function getBloomIntensityColor($intensity) {
    $intensity = max(0, min(100, $intensity));
    
    if ($intensity < 25) {
        return '#95a5a6'; // Gray
    } elseif ($intensity < 50) {
        return '#f39c12'; // Orange
    } elseif ($intensity < 75) {
        return '#e74c3c'; // Red
    } else {
        return '#e91e63'; // Pink
    }
}

/**
 * Calculate distance between two coordinates (Haversine formula)
 */
function calculateDistance($lat1, $lon1, $lat2, $lon2) {
    $earthRadius = 6371; // Earth's radius in kilometers
    
    $latDelta = deg2rad($lat2 - $lat1);
    $lonDelta = deg2rad($lon2 - $lon1);
    
    $a = sin($latDelta / 2) * sin($latDelta / 2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($lonDelta / 2) * sin($lonDelta / 2);
    
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    
    return $earthRadius * $c;
}

/**
 * Get current season based on date and hemisphere
 */
function getCurrentSeason($date = null, $hemisphere = 'north') {
    if (!$date) {
        $date = date('Y-m-d');
    }
    
    $month = (int)date('n', strtotime($date));
    $day = (int)date('j', strtotime($date));
    
    if ($hemisphere === 'north') {
        if (($month == 3 && $day >= 20) || ($month > 3 && $month < 6) || ($month == 6 && $day < 21)) {
            return 'Spring';
        } elseif (($month == 6 && $day >= 21) || ($month > 6 && $month < 9) || ($month == 9 && $day < 23)) {
            return 'Summer';
        } elseif (($month == 9 && $day >= 23) || ($month > 9 && $month < 12) || ($month == 12 && $day < 21)) {
            return 'Autumn';
        } else {
            return 'Winter';
        }
    } else {
        // Southern hemisphere - seasons are opposite
        if (($month == 9 && $day >= 23) || ($month > 9 && $month < 12) || ($month == 12 && $day < 21)) {
            return 'Spring';
        } elseif (($month == 12 && $day >= 21) || ($month > 12 || $month < 3) || ($month == 3 && $day < 20)) {
            return 'Summer';
        } elseif (($month == 3 && $day >= 20) || ($month > 3 && $month < 6) || ($month == 6 && $day < 21)) {
            return 'Autumn';
        } else {
            return 'Winter';
        }
    }
}

/**
 * Generate bloom prediction based on historical data
 */
function predictBloomProbability($ndviHistory, $currentSeason, $location) {
    if (empty($ndviHistory)) {
        return 0;
    }
    
    // Simple prediction algorithm
    $recentNDVI = array_slice($ndviHistory, -4); // Last 4 weeks
    $avgRecentNDVI = array_sum($recentNDVI) / count($recentNDVI);
    
    $baseProbability = $avgRecentNDVI * 100;
    
    // Seasonal adjustments
    $seasonalMultiplier = 1.0;
    switch ($currentSeason) {
        case 'Spring':
            $seasonalMultiplier = 1.5;
            break;
        case 'Summer':
            $seasonalMultiplier = 1.2;
            break;
        case 'Autumn':
            $seasonalMultiplier = 0.8;
            break;
        case 'Winter':
            $seasonalMultiplier = 0.3;
            break;
    }
    
    $probability = $baseProbability * $seasonalMultiplier;
    
    // Clamp to 0-100 range
    return max(0, min(100, round($probability)));
}

/**
 * Cache API responses
 */
function cacheAPIResponse($key, $data, $ttl = 3600) {
    $db = Database::getInstance()->getConnection();
    
    $expiresAt = date('Y-m-d H:i:s', time() + $ttl);
    
    $stmt = $db->prepare("
        INSERT OR REPLACE INTO api_cache (cache_key, cache_data, expires_at) 
        VALUES (?, ?, ?)
    ");
    
    return $stmt->execute([$key, json_encode($data), $expiresAt]);
}

/**
 * Get cached API response
 */
function getCachedAPIResponse($key) {
    $db = Database::getInstance()->getConnection();
    
    $stmt = $db->prepare("
        SELECT cache_data FROM api_cache 
        WHERE cache_key = ? AND expires_at > datetime('now')
    ");
    
    $stmt->execute([$key]);
    $result = $stmt->fetch();
    
    if ($result) {
        return json_decode($result['cache_data'], true);
    }
    
    return null;
}

/**
 * Clean expired cache entries
 */
function cleanExpiredCache() {
    $db = Database::getInstance()->getConnection();
    
    $stmt = $db->prepare("DELETE FROM api_cache WHERE expires_at <= datetime('now')");
    return $stmt->execute();
}

/**
 * Get user's current session ID
 */
function getUserSessionId() {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['user_id'] = uniqid('user_', true);
    }
    return $_SESSION['user_id'];
}

/**
 * Add location to user's watchlist
 */
function addToWatchlist($locationId) {
    $db = Database::getInstance()->getConnection();
    $userId = getUserSessionId();
    
    $stmt = $db->prepare("
        INSERT OR IGNORE INTO user_watchlist (user_session, location_id) 
        VALUES (?, ?)
    ");
    
    return $stmt->execute([$userId, $locationId]);
}

/**
 * Remove location from user's watchlist
 */
function removeFromWatchlist($locationId) {
    $db = Database::getInstance()->getConnection();
    $userId = getUserSessionId();
    
    $stmt = $db->prepare("
        DELETE FROM user_watchlist 
        WHERE user_session = ? AND location_id = ?
    ");
    
    return $stmt->execute([$userId, $locationId]);
}

/**
 * Check if location is in user's watchlist
 */
function isInWatchlist($locationId) {
    $db = Database::getInstance()->getConnection();
    $userId = getUserSessionId();
    
    $stmt = $db->prepare("
        SELECT COUNT(*) as count FROM user_watchlist 
        WHERE user_session = ? AND location_id = ?
    ");
    
    $stmt->execute([$userId, $locationId]);
    $result = $stmt->fetch();
    
    return $result['count'] > 0;
}

/**
 * Get user's watchlist
 */
function getUserWatchlist() {
    $db = Database::getInstance()->getConnection();
    $userId = getUserSessionId();
    
    $stmt = $db->prepare("
        SELECT l.*, w.created_at as added_at
        FROM locations l
        JOIN user_watchlist w ON l.id = w.location_id
        WHERE w.user_session = ?
        ORDER BY w.created_at DESC
    ");
    
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/**
 * Generate random bloom event data for demonstration
 */
function generateMockBloomData($locationId, $days = 30) {
    $data = [];
    $startDate = new DateTime('-' . $days . ' days');
    
    for ($i = 0; $i < $days; $i++) {
        $date = clone $startDate;
        $date->add(new DateInterval('P' . $i . 'D'));
        
        // Simulate seasonal bloom patterns
        $dayOfYear = (int)$date->format('z');
        $bloomIntensity = 50 + 40 * sin(($dayOfYear - 80) * 2 * pi() / 365);
        $bloomIntensity = max(0, min(100, $bloomIntensity + rand(-20, 20)));
        
        $data[] = [
            'date' => $date->format('Y-m-d'),
            'intensity' => round($bloomIntensity),
            'temperature' => rand(15, 30),
            'humidity' => rand(40, 80),
            'precipitation' => rand(0, 10)
        ];
    }
    
    return $data;
}
?>