<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BloomWatch - NASA Global Flowering Monitor</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- Google Fonts - Space Grotesk -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS Frameworks -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Leaflet Map -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- AOS Animation Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <!-- Meta tags for SEO -->
    <meta name="description" content="BloomWatch - Monitor global flowering phenology using NASA Earth observations and satellite data">
    <meta name="keywords" content="NASA, Space Apps, flowering, phenology, vegetation, NDVI, bloom monitoring, satellite data">
    <meta name="author" content="NASA Space Apps Challenge Team">
    
    <!-- Open Graph tags -->
    <meta property="og:title" content="BloomWatch - NASA Global Flowering Monitor">
    <meta property="og:description" content="Track plant blooming events worldwide using NASA satellite data and advanced analytics">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $_SERVER['REQUEST_URI']; ?>">
</head>
<body class="antialiased">
    <!-- Scroll Progress Bar -->
    <div id="scroll-progress-bar" class="scroll-progress"></div>

    <!-- Animated Background -->
    <div class="fixed-top w-100 h-100" style="z-index: -1; overflow: hidden;">
        <div id="glow1" class="glow-element position-absolute" style="top: -25%; right: 0; width: 40vw; height: 40vw; background: rgba(192, 132, 252, 0.03); border-radius: 50%; filter: blur(150px); pointer-events: none;"></div>
        <div id="glow2" class="glow-element position-absolute animate-float" style="bottom: -25%; left: 0; width: 40vw; height: 40vw; background: rgba(59, 130, 246, 0.03); border-radius: 50%; filter: blur(150px); pointer-events: none;"></div>
    </div>

    <!-- Header -->
    <header id="header" class="position-fixed w-100" style="top: 0; z-index: 1050; transition: all 0.3s ease;">
        <div class="container mx-auto px-4 py-3 d-flex justify-content-between align-items-center glassmorphism mt-3 rounded-3">
            <a href="index.php" class="navbar-brand d-flex align-items-center gap-2 text-decoration-none">
                <i class="fas fa-seedling logo-img" style="font-size: 2rem; color: var(--primary-color);"></i>
                <strong class="text-gradient">BloomWatch</strong>
            </a>
            <nav class="d-none d-md-flex align-items-center gap-4" style="font-size: 0.9rem; font-weight: 500;">
                <a href="index.php?page=dashboard" class="text-decoration-none text-muted hover-text-white <?php echo ($page === 'dashboard') ? 'text-white' : ''; ?>">Dashboard</a>
                <a href="index.php?page=map" class="text-decoration-none text-muted hover-text-white <?php echo ($page === 'map') ? 'text-white' : ''; ?>">Global Map</a>
                <a href="index.php?page=data" class="text-decoration-none text-muted hover-text-white <?php echo ($page === 'data') ? 'text-white' : ''; ?>">Data Explorer</a>
                <a href="index.php?page=analytics" class="text-decoration-none text-muted hover-text-white <?php echo ($page === 'analytics') ? 'text-white' : ''; ?>">Analytics</a>
            </nav>
            <button id="mobile-menu-button" class="btn d-md-none text-white fs-4" style="z-index: 1051;">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="position-fixed top-0 start-0 w-100 h-100 d-none flex-column align-items-center justify-content-center" style="background: rgba(0,0,0,0.8); backdrop-filter: blur(20px); z-index: 1040;">
        <button id="mobile-menu-close-button" class="position-absolute btn text-white fs-3" style="top: 1.5rem; right: 1.5rem;">
            <i class="fas fa-times"></i>
        </button>
        <nav class="d-flex flex-column align-items-center gap-4 fs-2">
            <a href="index.php?page=dashboard" class="mobile-menu-link text-decoration-none text-white">Dashboard</a>
            <a href="index.php?page=map" class="mobile-menu-link text-decoration-none text-white">Global Map</a>
            <a href="index.php?page=data" class="mobile-menu-link text-decoration-none text-white">Data Explorer</a>
            <a href="index.php?page=analytics" class="mobile-menu-link text-decoration-none text-white">Analytics</a>
        </nav>
    </div>
    
    <!-- Main Content -->
    <main class="position-relative container-fluid px-4" style="z-index: 10; padding-top: 6rem;">
        
        <!-- NASA API Status Banner -->
        <div class="row">
            <div class="col-12">
                <div class="glassmorphism rounded-3 p-3 mb-4 d-flex align-items-center justify-content-between" data-aos="fade-down">
                    <div class="d-flex align-items-center gap-2">
                        <i class="fas fa-satellite text-gradient fs-5"></i>
                        <span class="text-white fw-bold">Live NASA Data</span>
                        <span class="badge bg-success ms-2">Connected</span>
                    </div>
                    <small class="text-muted">Last updated: <?php echo date('M d, Y H:i'); ?> UTC</small>
                </div>
            </div>
        </div>