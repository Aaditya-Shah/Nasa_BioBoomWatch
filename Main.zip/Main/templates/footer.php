    </div> <!-- End container-fluid -->
    
    <!-- Footer -->
    <footer class="border-top mt-5 py-5" style="border-color: rgba(255,255,255,0.1) !important;">
        <div class="container text-center">
            <div class="glassmorphism interactive-glow d-inline-flex align-items-center justify-content-center gap-4 mb-4 rounded-pill px-4 py-2">
                <a href="https://api.nasa.gov/" target="_blank" class="text-decoration-none text-muted hover-text-white p-2 rounded-circle" title="NASA APIs">
                    <i class="fas fa-satellite"></i>
                </a>
                <a href="https://github.com" target="_blank" class="text-decoration-none text-muted hover-text-white p-2 rounded-circle" title="GitHub">
                    <i class="fab fa-github"></i>
                </a>
                <a href="https://earthdata.nasa.gov/" target="_blank" class="text-decoration-none text-muted hover-text-white p-2 rounded-circle" title="NASA Earthdata">
                    <i class="fas fa-globe"></i>
                </a>
                <a href="#" onclick="showAbout()" class="text-decoration-none text-muted hover-text-white p-2 rounded-circle" title="About Project">
                    <i class="fas fa-info-circle"></i>
                </a>
            </div>
            <p class="text-muted mb-2">
                &copy; <span id="footer-year">2025</span> <span class="text-gradient fw-bold">BloomWatch</span>. 
                Powered by NASA Open Data
            </p>
            <small class="text-muted">
                NASA Space Apps Challenge 2025 • Team Nex Hunter • Itahari, Nepal
            </small>
        </div>
    </footer>

    <!-- Scroll to Top Button -->
    <a href="#" id="scrollTopBtn" class="position-fixed btn btn-primary rounded-circle" 
       style="bottom: 2rem; right: 2rem; width: 3rem; height: 3rem; transform: translateY(5rem); transition: transform 0.3s ease; z-index: 1000;"
       onclick="window.scrollTo({top: 0, behavior: 'smooth'})">
        <i class="fas fa-arrow-up"></i>
    </a>
    
    <!-- Modals -->
    
    <!-- Watchlist Modal -->
    <div class="modal fade" id="watchlistModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-heart me-2"></i>My Watchlist</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="watchlistContent">
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Settings Modal -->
    <div class="modal fade" id="settingsModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-cog me-2"></i>Settings</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="settingsForm">
                        <div class="mb-3">
                            <label class="form-label">Temperature Unit</label>
                            <select class="form-select" id="tempUnit">
                                <option value="celsius">Celsius (°C)</option>
                                <option value="fahrenheit">Fahrenheit (°F)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notifications</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="emailNotifications" checked>
                                <label class="form-check-label" for="emailNotifications">
                                    Email notifications for bloom events
                                </label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Map Default View</label>
                            <select class="form-select" id="defaultMapView">
                                <option value="global">Global View</option>
                                <option value="local" selected>Local Region (Nepal)</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="saveSettings()">Save Settings</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- About Modal -->
    <div class="modal fade" id="aboutModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-info-circle me-2"></i>About BloomWatch</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h6>NASA Space Apps Challenge 2025</h6>
                            <p>
                                BloomWatch is an Earth observation application for monitoring global flowering phenology. 
                                Using NASA satellite data, we track vegetation changes and predict blooming events worldwide.
                            </p>
                            
                            <h6>Challenge: BloomWatch</h6>
                            <p>
                                <small>
                                    Witness the pulse of life across our planet! From season to season and year to year, 
                                    Earth's vegetation is constantly changing, providing critical information on plant species, 
                                    crops, seasonal effects, pollen sources, and changes in plant phenology.
                                </small>
                            </p>
                            
                            <h6>Technology Stack</h6>
                            <ul>
                                <li>NASA APIs (MODIS, Landsat, EPIC, EONET)</li>
                                <li>PHP Backend with SQLite Database</li>
                                <li>Leaflet.js for Interactive Maps</li>
                                <li>Chart.js for Data Visualization</li>
                                <li>Bootstrap 5 for Responsive UI</li>
                            </ul>
                        </div>
                        <div class="col-md-4">
                            <h6>Team Information</h6>
                            <p><strong>Team:</strong> Nex Hunter<br>
                            <strong>Location:</strong> Itahari, Nepal<br>
                            <strong>Event:</strong> NASA Space Apps 2025</p>
                            
                            <h6>Data Sources</h6>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-satellite text-primary me-2"></i>NASA MODIS NDVI</li>
                                <li><i class="fas fa-satellite text-success me-2"></i>NASA Landsat Imagery</li>
                                <li><i class="fas fa-globe text-info me-2"></i>NASA EPIC Earth Images</li>
                                <li><i class="fas fa-exclamation-triangle text-warning me-2"></i>NASA EONET Events</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="assets/js/main.js"></script>
    
    <!-- Portfolio-style Interactive Effects -->
    <script>
        // Initialize AOS
        AOS.init({ 
            duration: 800, 
            once: true, 
            offset: 50 
        });
        
        // Interactive Glow Effect
        document.addEventListener('mousemove', (e) => {
            document.querySelectorAll('.interactive-glow').forEach(el => {
                const rect = el.getBoundingClientRect();
                el.style.setProperty('--mouse-x', `${e.clientX - rect.left}px`);
                el.style.setProperty('--mouse-y', `${e.clientY - rect.top}px`);
            });
        });

        // Mobile Menu
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const mobileMenuCloseButton = document.getElementById('mobile-menu-close-button');
        const mobileMenu = document.getElementById('mobile-menu');
        const mobileMenuLinks = document.querySelectorAll('.mobile-menu-link');
        
        const toggleMenu = () => {
            mobileMenu.classList.toggle('d-none');
            mobileMenu.classList.toggle('d-flex');
            document.body.classList.toggle('overflow-hidden');
        };
        
        if (mobileMenuButton) mobileMenuButton.addEventListener('click', toggleMenu);
        if (mobileMenuCloseButton) mobileMenuCloseButton.addEventListener('click', toggleMenu);
        mobileMenuLinks.forEach(link => link.addEventListener('click', toggleMenu));

        // Scroll Effects
        const scrollProgressBar = document.getElementById('scroll-progress-bar');
        const header = document.getElementById('header');
        const glow1 = document.getElementById('glow1');
        const glow2 = document.getElementById('glow2');

        window.addEventListener('scroll', () => {
            const scrollTop = document.documentElement.scrollTop;
            const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrollTopBtn = document.getElementById('scrollTopBtn');
            
            // Progress bar
            if (scrollProgressBar) {
                scrollProgressBar.style.width = `${(scrollTop / scrollHeight) * 100}%`;
            }
            
            // Scroll to top button
            if (scrollTopBtn) {
                if (scrollTop > 300) {
                    scrollTopBtn.style.transform = 'translateY(0)';
                } else {
                    scrollTopBtn.style.transform = 'translateY(5rem)';
                }
            }
            
            // Header background on scroll
            if (header) {
                if (scrollTop > 50) {
                    header.style.background = 'rgba(0,0,0,0.2)';
                    header.style.backdropFilter = 'blur(20px)';
                } else {
                    header.style.background = 'transparent';
                    header.style.backdropFilter = 'none';
                }
            }
            
            // Parallax glows
            if (glow1) glow1.style.transform = `translateY(${scrollTop * 0.1}px)`;
            if (glow2) glow2.style.transform = `translateY(${scrollTop * 0.05}px)`;
        });
    </script>
    
    <script>
        // Global functions for modals
        function showWatchlist() {
            $('#watchlistModal').modal('show');
            loadWatchlist();
        }
        
        function showSettings() {
            $('#settingsModal').modal('show');
        }
        
        function showAbout() {
            $('#aboutModal').modal('show');
        }
        
        function saveSettings() {
            // Save settings to localStorage
            const settings = {
                tempUnit: document.getElementById('tempUnit').value,
                emailNotifications: document.getElementById('emailNotifications').checked,
                defaultMapView: document.getElementById('defaultMapView').value
            };
            
            localStorage.setItem('bloomwatch_settings', JSON.stringify(settings));
            $('#settingsModal').modal('hide');
            
            // Show success message
            showNotification('Settings saved successfully!', 'success');
        }
        
        function loadWatchlist() {
            fetch('api/watchlist.php')
                .then(response => response.json())
                .then(data => {
                    const content = document.getElementById('watchlistContent');
                    if (data.length === 0) {
                        content.innerHTML = '<p class="text-muted text-center">No locations in your watchlist yet.</p>';
                    } else {
                        let html = '<div class="row">';
                        data.forEach(location => {
                            html += `
                                <div class="col-md-6 mb-3">
                                    <div class="card">
                                        <div class="card-body">
                                            <h6 class="card-title">${location.name}</h6>
                                            <p class="card-text">
                                                <small class="text-muted">
                                                    <i class="fas fa-map-marker-alt me-1"></i>
                                                    ${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}<br>
                                                    <i class="fas fa-globe me-1"></i>
                                                    ${location.country}, ${location.region}
                                                </small>
                                            </p>
                                            <button class="btn btn-sm btn-outline-danger" onclick="removeFromWatchlist(${location.id})">
                                                <i class="fas fa-trash me-1"></i> Remove
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            `;
                        });
                        html += '</div>';
                        content.innerHTML = html;
                    }
                })
                .catch(error => {
                    console.error('Error loading watchlist:', error);
                    document.getElementById('watchlistContent').innerHTML = 
                        '<div class="alert alert-danger">Error loading watchlist.</div>';
                });
        }
        
        function showNotification(message, type = 'info') {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
            alertDiv.style.cssText = 'top: 80px; right: 20px; z-index: 9999; min-width: 300px;';
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.body.appendChild(alertDiv);
            
            // Auto-dismiss after 5 seconds
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 5000);
        }
        
        // Load saved settings on page load
        document.addEventListener('DOMContentLoaded', function() {
            const savedSettings = localStorage.getItem('bloomwatch_settings');
            if (savedSettings) {
                const settings = JSON.parse(savedSettings);
                if (document.getElementById('tempUnit')) {
                    document.getElementById('tempUnit').value = settings.tempUnit || 'celsius';
                }
                if (document.getElementById('emailNotifications')) {
                    document.getElementById('emailNotifications').checked = settings.emailNotifications !== false;
                }
                if (document.getElementById('defaultMapView')) {
                    document.getElementById('defaultMapView').value = settings.defaultMapView || 'local';
                }
            }
        });
    </script>
</body>
</html>