<?php
/**
 * BloomWatch - Global Flowering Phenology Monitoring Application
 * NASA Space Apps Challenge 2025
 * 
 * Main entry point for the application
 */

session_start();
require_once 'config/database.php';
require_once 'config/nasa_api.php';
require_once 'includes/functions.php';

// Set content type
header('Content-Type: text/html; charset=UTF-8');

// Get the requested page
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Include header
include 'templates/header.php';

// Route to appropriate page
switch ($page) {
    case 'dashboard':
        include 'pages/dashboard.php';
        break;
    case 'map':
        include 'pages/map.php';
        break;
    case 'data':
        include 'pages/data.php';
        break;
    case 'analytics':
        include 'pages/analytics.php';
        break;
    case 'api':
        include 'api/index.php';
        break;
    default:
        include 'pages/dashboard.php';
        break;
}

// Include footer
include 'templates/footer.php';
?>