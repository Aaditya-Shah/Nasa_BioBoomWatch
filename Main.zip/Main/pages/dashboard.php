<?php
/**
 * Dashboard Page - Main overview of global bloom activity
 */

require_once 'config/database.php';
require_once 'config/nasa_api.php';

$db = Database::getInstance()->getConnection();

// Get recent observations
$recentObservations = $db->query("
    SELECT l.name, l.country, vo.observation_date, vo.bloom_status, vo.bloom_intensity, vo.ndvi_value
    FROM vegetation_observations vo
    JOIN locations l ON vo.location_id = l.id
    ORDER BY vo.observation_date DESC
    LIMIT 10
")->fetchAll();

// Get bloom statistics
$bloomStats = $db->query("
    SELECT 
        bloom_status,
        COUNT(*) as count,
        ROUND(AVG(bloom_intensity), 1) as avg_intensity
    FROM vegetation_observations 
    WHERE observation_date >= date('now', '-30 days')
    GROUP BY bloom_status
")->fetchAll();

// Get top blooming locations
$topBloomingLocations = $db->query("
    SELECT 
        l.name, l.country, l.latitude, l.longitude,
        AVG(vo.bloom_intensity) as avg_intensity,
        COUNT(vo.id) as observation_count
    FROM locations l
    JOIN vegetation_observations vo ON l.id = vo.location_id
    WHERE vo.observation_date >= date('now', '-7 days')
    AND vo.bloom_status = 'blooming'
    GROUP BY l.id
    ORDER BY avg_intensity DESC
    LIMIT 5
")->fetchAll();

// Get NASA APOD
$apodData = NasaAPI::getAPOD();
?>

<!-- Hero Section -->
<section class="row min-vh-50 d-flex align-items-center justify-content-center text-center pt-5 mb-5">
    <div class="col-12">
        <div class="mb-4" data-aos="fade-down">
            <span class="badge rounded-pill" style="background: rgba(192, 132, 252, 0.1); color: var(--primary-color); padding: 0.5rem 1rem;">
                NASA Space Apps Challenge 2025
            </span>
        </div>
        <h1 class="display-3 fw-bold mb-4" data-aos="fade-up">
            <span class="text-gradient">BloomWatch</span>
        </h1>
        <p class="fs-4 text-secondary mb-5" data-aos="fade-up" data-aos-delay="200">
            Global Flowering Phenology Monitor
        </p>
        <p class="lead text-muted mb-4" data-aos="fade-up" data-aos-delay="300">
            With <span class="text-gradient fw-bold">12+ NASA APIs</span> of real-time satellite data integration
        </p>
        <div class="d-flex flex-column flex-sm-row justify-content-center gap-3 mb-5" data-aos="fade-up" data-aos-delay="400">
            <a href="index.php?page=map" class="btn btn-primary px-4 py-3 fw-bold">
                <i class="fas fa-map me-2"></i>Explore Global Map
            </a>
            <a href="index.php?page=data" class="btn btn-outline-light px-4 py-3">
                <i class="fas fa-database me-2"></i>View Live Data
            </a>
        </div>
        
        <div class="row g-3 mt-4" data-aos="fade-up" data-aos-delay="500">
            <div class="col-md-4">
                <div class="glassmorphism interactive-glow rounded-3 p-3 text-center">
                    <i class="fas fa-satellite text-gradient fs-3 mb-2"></i>
                    <div class="fw-bold text-white">NASA MODIS Data</div>
                    <small class="text-secondary">Real-time vegetation indices</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="glassmorphism interactive-glow rounded-3 p-3 text-center">
                    <i class="fas fa-leaf text-gradient fs-3 mb-2"></i>
                    <div class="fw-bold text-white">NDVI Analysis</div>
                    <small class="text-secondary">Advanced bloom detection</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="glassmorphism interactive-glow rounded-3 p-3 text-center">
                    <i class="fas fa-globe text-gradient fs-3 mb-2"></i>
                    <div class="fw-bold text-white">Global Coverage</div>
                    <small class="text-secondary">Worldwide monitoring system</small>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="row">
    <!-- Dashboard Content -->
                        <p class="mb-0">
                            <strong><?php echo count($recentObservations); ?></strong> Recent Observations
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Bloom Statistics Cards -->
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-flower me-2"></i>Currently Blooming
                </h5>
            </div>
            <div class="card-body">
                <?php 
                $bloomingCount = 0;
                $bloomingIntensity = 0;
                foreach ($bloomStats as $stat) {
                    if ($stat['bloom_status'] === 'blooming') {
                        $bloomingCount = $stat['count'];
                        $bloomingIntensity = $stat['avg_intensity'];
                        break;
                    }
                }
                ?>
                <div class="text-center">
                    <div class="display-4 text-success mb-2"><?php echo $bloomingCount; ?></div>
                    <p class="mb-2">Locations in bloom</p>
                    <div class="progress">
                        <div class="progress-bar bg-success" style="width: <?php echo $bloomingIntensity; ?>%"></div>
                    </div>
                    <small class="text-muted">Average intensity: <?php echo $bloomingIntensity; ?>%</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-seedling me-2"></i>Growing Season
                </h5>
            </div>
            <div class="card-body">
                <?php 
                $growingCount = 0;
                $growingIntensity = 0;
                foreach ($bloomStats as $stat) {
                    if ($stat['bloom_status'] === 'growing') {
                        $growingCount = $stat['count'];
                        $growingIntensity = $stat['avg_intensity'];
                        break;
                    }
                }
                ?>
                <div class="text-center">
                    <div class="display-4 text-info mb-2"><?php echo $growingCount; ?></div>
                    <p class="mb-2">Locations growing</p>
                    <div class="progress">
                        <div class="progress-bar bg-info" style="width: <?php echo $growingIntensity; ?>%"></div>
                    </div>
                    <small class="text-muted">Average intensity: <?php echo $growingIntensity; ?>%</small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <div class="card-header bg-secondary text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-snowflake me-2"></i>Dormant Season
                </h5>
            </div>
            <div class="card-body">
                <?php 
                $dormantCount = 0;
                foreach ($bloomStats as $stat) {
                    if ($stat['bloom_status'] === 'dormant') {
                        $dormantCount = $stat['count'];
                        break;
                    }
                }
                ?>
                <div class="text-center">
                    <div class="display-4 text-secondary mb-2"><?php echo $dormantCount; ?></div>
                    <p class="mb-2">Locations dormant</p>
                    <p class="text-muted">Seasonal rest period</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Top Blooming Locations -->
    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-trophy me-2"></i>Top Blooming Locations
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($topBloomingLocations)): ?>
                    <p class="text-muted text-center">No blooming locations in the past week.</p>
                <?php else: ?>
                    <?php foreach ($topBloomingLocations as $index => $location): ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="mb-1">
                                    <span class="badge bg-warning text-dark me-2">#<?php echo $index + 1; ?></span>
                                    <?php echo htmlspecialchars($location['name']); ?>
                                </h6>
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    <?php echo htmlspecialchars($location['country']); ?>
                                </small>
                            </div>
                            <div class="text-end">
                                <div class="text-success fw-bold"><?php echo round($location['avg_intensity']); ?>%</div>
                                <small class="text-muted"><?php echo $location['observation_count']; ?> obs.</small>
                            </div>
                        </div>
                        <?php if ($index < count($topBloomingLocations) - 1): ?>
                            <hr class="my-2">
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-clock me-2"></i>Recent Observations
                </h5>
            </div>
            <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                <?php foreach ($recentObservations as $obs): ?>
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h6 class="mb-1"><?php echo htmlspecialchars($obs['name']); ?></h6>
                            <small class="text-muted">
                                <i class="fas fa-calendar me-1"></i>
                                <?php echo formatDate($obs['observation_date']); ?>
                            </small>
                        </div>
                        <div class="text-end">
                            <span class="badge" style="background-color: <?php echo getBloomStatusColor($obs['bloom_status']); ?>">
                                <?php echo ucfirst($obs['bloom_status']); ?>
                            </span>
                            <div class="small text-muted mt-1">
                                NDVI: <?php echo $obs['ndvi_value']; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Global Bloom Activity Map -->
<div class="row">
    <div class="col-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-globe me-2"></i>Global Bloom Activity
                </h5>
            </div>
            <div class="card-body">
                <div id="globalMap" style="height: 400px; width: 100%;"></div>
            </div>
        </div>
    </div>
</div>

<!-- NASA APOD Section -->
<?php if ($apodData && isset($apodData['url'])): ?>
<div class="row">
    <div class="col-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-star me-2"></i>NASA Astronomy Picture of the Day
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <?php if (isset($apodData['media_type']) && $apodData['media_type'] === 'image'): ?>
                            <img src="<?php echo $apodData['url']; ?>" class="img-fluid rounded" alt="NASA APOD">
                        <?php elseif (isset($apodData['media_type']) && $apodData['media_type'] === 'video'): ?>
                            <div class="ratio ratio-16x9">
                                <iframe src="<?php echo $apodData['url']; ?>" allowfullscreen></iframe>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <h5><?php echo htmlspecialchars($apodData['title'] ?? 'NASA APOD'); ?></h5>
                        <p class="text-muted">
                            <i class="fas fa-calendar me-1"></i>
                            <?php echo formatDate($apodData['date'] ?? date('Y-m-d')); ?>
                        </p>
                        <p><?php echo htmlspecialchars(substr($apodData['explanation'] ?? '', 0, 300)) . '...'; ?></p>
                        <?php if (isset($apodData['copyright'])): ?>
                            <small class="text-muted">Copyright: <?php echo htmlspecialchars($apodData['copyright']); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize global map
    const map = L.map('globalMap').setView([27.7172, 85.3240], 2);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Add markers for locations
    <?php 
    $locations = $db->query("SELECT * FROM locations")->fetchAll();
    foreach ($locations as $location): 
    ?>
        L.marker([<?php echo $location['latitude']; ?>, <?php echo $location['longitude']; ?>])
            .addTo(map)
            .bindPopup(`
                <strong><?php echo htmlspecialchars($location['name']); ?></strong><br>
                <?php echo htmlspecialchars($location['country']); ?><br>
                <em><?php echo htmlspecialchars($location['ecosystem_type']); ?></em>
            `);
    <?php endforeach; ?>
});
</script>