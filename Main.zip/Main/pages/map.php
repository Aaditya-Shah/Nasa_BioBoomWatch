<?php
/**
 * Global Map Page - Interactive world map showing bloom activity
 */

require_once 'config/database.php';

$db = Database::getInstance()->getConnection();

// Get all locations with their latest observations
$locations = $db->query("
    SELECT 
        l.*,
        vo.bloom_status,
        vo.bloom_intensity,
        vo.ndvi_value,
        vo.observation_date
    FROM locations l
    LEFT JOIN vegetation_observations vo ON l.id = vo.location_id
    WHERE vo.id IN (
        SELECT MAX(id) 
        FROM vegetation_observations 
        GROUP BY location_id
    ) OR vo.id IS NULL
")->fetchAll();
?>

<div class="row">
    <div class="col-12 mb-4">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="card-title mb-0">
                        <i class="fas fa-globe me-2"></i>Global Flowering Phenology Map
                    </h4>
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-primary active" onclick="showLayer('bloom')">
                            <i class="fas fa-flower me-1"></i> Bloom Status
                        </button>
                        <button type="button" class="btn btn-outline-success" onclick="showLayer('ndvi')">
                            <i class="fas fa-leaf me-1"></i> NDVI
                        </button>
                        <button type="button" class="btn btn-outline-info" onclick="showLayer('satellite')">
                            <i class="fas fa-satellite me-1"></i> Satellite
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div id="worldMap" style="height: 600px; width: 100%;"></div>
            </div>
        </div>
    </div>
</div>

<!-- Map Controls Panel -->
<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-filter me-2"></i>Map Filters
                </h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label">Bloom Status</label>
                    <select class="form-select" id="bloomFilter" onchange="updateMapFilters()">
                        <option value="all">All Status</option>
                        <option value="blooming">Blooming</option>
                        <option value="growing">Growing</option>
                        <option value="dormant">Dormant</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Ecosystem Type</label>
                    <select class="form-select" id="ecosystemFilter" onchange="updateMapFilters()">
                        <option value="all">All Ecosystems</option>
                        <option value="Tropical Rainforest">Tropical Rainforest</option>
                        <option value="Temperate Forest">Temperate Forest</option>
                        <option value="Agricultural">Agricultural</option>
                        <option value="Savanna">Savanna</option>
                        <option value="Alpine">Alpine</option>
                        <option value="Boreal Forest">Boreal Forest</option>
                        <option value="Semi-arid">Semi-arid</option>
                        <option value="Arid">Arid</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">NDVI Range</label>
                    <div class="row">
                        <div class="col-6">
                            <input type="number" class="form-control form-control-sm" 
                                   id="ndviMin" placeholder="Min" step="0.1" min="0" max="1" 
                                   onchange="updateMapFilters()">
                        </div>
                        <div class="col-6">
                            <input type="number" class="form-control form-control-sm" 
                                   id="ndviMax" placeholder="Max" step="0.1" min="0" max="1" 
                                   onchange="updateMapFilters()">
                        </div>
                    </div>
                </div>
                
                <button class="btn btn-outline-secondary btn-sm w-100" onclick="clearFilters()">
                    <i class="fas fa-times me-1"></i> Clear Filters
                </button>
            </div>
        </div>
        
        <!-- Legend -->
        <div class="card mt-3">
            <div class="card-header">
                <h6 class="card-title mb-0">
                    <i class="fas fa-palette me-2"></i>Legend
                </h6>
            </div>
            <div class="card-body">
                <div class="mb-2">
                    <span class="badge bg-danger me-2">●</span> Blooming (NDVI > 0.6)
                </div>
                <div class="mb-2">
                    <span class="badge bg-success me-2">●</span> Growing (NDVI 0.4-0.6)
                </div>
                <div class="mb-2">
                    <span class="badge bg-secondary me-2">●</span> Dormant (NDVI < 0.4)
                </div>
                <hr>
                <small class="text-muted">
                    <strong>NDVI:</strong> Normalized Difference Vegetation Index<br>
                    Higher values indicate healthier vegetation
                </small>
            </div>
        </div>
    </div>
    
    <!-- Location Details Panel -->
    <div class="col-md-9 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-info-circle me-2"></i>Location Details
                </h5>
            </div>
            <div class="card-body" id="locationDetails">
                <div class="text-center text-muted">
                    <i class="fas fa-mouse-pointer fa-2x mb-3"></i>
                    <p>Click on a location marker to view detailed information</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bloom Timeline Chart -->
<div class="row">
    <div class="col-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-line me-2"></i>Global Bloom Activity Timeline
                </h5>
            </div>
            <div class="card-body">
                <canvas id="bloomTimelineChart" height="100"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
let worldMap;
let markersLayer;
let currentLayer = 'bloom';
let allLocations = <?php echo json_encode($locations); ?>;

document.addEventListener('DOMContentLoaded', function() {
    initializeMap();
    initializeChart();
});

function initializeMap() {
    // Initialize the map
    worldMap = L.map('worldMap').setView([20, 0], 2);
    
    // Add base map layers
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    });
    
    const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles © Esri'
    });
    
    // Add default layer
    osmLayer.addTo(worldMap);
    
    // Create layer control
    const baseMaps = {
        "OpenStreetMap": osmLayer,
        "Satellite": satelliteLayer
    };
    
    L.control.layers(baseMaps).addTo(worldMap);
    
    // Initialize markers
    markersLayer = L.layerGroup().addTo(worldMap);
    updateMarkers();
}

function updateMarkers() {
    // Clear existing markers
    markersLayer.clearLayers();
    
    // Get filter values
    const bloomFilter = document.getElementById('bloomFilter').value;
    const ecosystemFilter = document.getElementById('ecosystemFilter').value;
    const ndviMin = parseFloat(document.getElementById('ndviMin').value) || 0;
    const ndviMax = parseFloat(document.getElementById('ndviMax').value) || 1;
    
    // Filter and add markers
    allLocations.forEach(location => {
        // Apply filters
        if (bloomFilter !== 'all' && location.bloom_status !== bloomFilter) return;
        if (ecosystemFilter !== 'all' && location.ecosystem_type !== ecosystemFilter) return;
        if (location.ndvi_value < ndviMin || location.ndvi_value > ndviMax) return;
        
        // Determine marker color based on bloom status
        let markerColor = '#6c757d'; // Default gray
        if (location.bloom_status === 'blooming') markerColor = '#dc3545';
        else if (location.bloom_status === 'growing') markerColor = '#28a745';
        
        // Create custom marker
        const marker = L.circleMarker([location.latitude, location.longitude], {
            color: markerColor,
            fillColor: markerColor,
            fillOpacity: 0.7,
            radius: Math.max(5, (location.bloom_intensity || 0) / 10)
        });
        
        // Add popup
        marker.bindPopup(`
            <div class="p-2">
                <h6 class="mb-2">${location.name}</h6>
                <p class="mb-1"><strong>Country:</strong> ${location.country || 'N/A'}</p>
                <p class="mb-1"><strong>Ecosystem:</strong> ${location.ecosystem_type || 'N/A'}</p>
                <p class="mb-1"><strong>Status:</strong> 
                    <span class="badge" style="background-color: ${markerColor}">
                        ${location.bloom_status || 'Unknown'}
                    </span>
                </p>
                <p class="mb-1"><strong>NDVI:</strong> ${location.ndvi_value || 'N/A'}</p>
                <p class="mb-1"><strong>Intensity:</strong> ${location.bloom_intensity || 0}%</p>
                <hr class="my-2">
                <button class="btn btn-sm btn-primary" onclick="showLocationDetails(${location.id})">
                    View Details
                </button>
                <button class="btn btn-sm btn-outline-danger ms-1" onclick="addToWatchlist(${location.id})">
                    <i class="fas fa-heart"></i>
                </button>
            </div>
        `);
        
        // Add click event
        marker.on('click', function() {
            showLocationDetails(location.id);
        });
        
        markersLayer.addLayer(marker);
    });
}

function showLayer(layerType) {
    // Update active button
    document.querySelectorAll('.btn-group .btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    currentLayer = layerType;
    
    if (layerType === 'satellite') {
        // Switch to satellite view
        worldMap.eachLayer(layer => {
            if (layer.options && layer.options.attribution && layer.options.attribution.includes('OpenStreetMap')) {
                worldMap.removeLayer(layer);
            }
        });
        
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Tiles © Esri'
        }).addTo(worldMap);
    }
    
    updateMarkers();
}

function updateMapFilters() {
    updateMarkers();
}

function clearFilters() {
    document.getElementById('bloomFilter').value = 'all';
    document.getElementById('ecosystemFilter').value = 'all';
    document.getElementById('ndviMin').value = '';
    document.getElementById('ndviMax').value = '';
    updateMarkers();
}

function showLocationDetails(locationId) {
    // Find location data
    const location = allLocations.find(loc => loc.id == locationId);
    if (!location) return;
    
    // Load recent data for this location
    fetch(`api/location.php?id=${locationId}`)
        .then(response => response.json())
        .then(data => {
            const detailsPanel = document.getElementById('locationDetails');
            detailsPanel.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <h5>${location.name}</h5>
                        <p class="text-muted mb-3">
                            <i class="fas fa-map-marker-alt me-1"></i>
                            ${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}<br>
                            <i class="fas fa-globe me-1"></i>
                            ${location.country}, ${location.region}<br>
                            <i class="fas fa-tree me-1"></i>
                            ${location.ecosystem_type}
                        </p>
                        
                        <div class="row">
                            <div class="col-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6>Current Status</h6>
                                        <span class="badge fs-6" style="background-color: ${getBloomStatusColor(location.bloom_status)}">
                                            ${location.bloom_status || 'Unknown'}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6>NDVI Value</h6>
                                        <h4 class="text-success">${location.ndvi_value || 'N/A'}</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <h6>Recent Activity</h6>
                        <canvas id="locationChart" width="400" height="200"></canvas>
                    </div>
                </div>
                
                <div class="mt-3">
                    <button class="btn btn-primary me-2" onclick="addToWatchlist(${locationId})">
                        <i class="fas fa-heart me-1"></i> Add to Watchlist
                    </button>
                    <button class="btn btn-outline-secondary" onclick="getNASAImagery(${location.latitude}, ${location.longitude})">
                        <i class="fas fa-satellite me-1"></i> View NASA Imagery
                    </button>
                </div>
            `;
            
            // Create mini chart for this location
            createLocationChart(data.timeline || []);
        })
        .catch(error => {
            console.error('Error loading location details:', error);
        });
}

function createLocationChart(timelineData) {
    const ctx = document.getElementById('locationChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: timelineData.map(d => d.date),
            datasets: [{
                label: 'NDVI',
                data: timelineData.map(d => d.ndvi),
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1
                }
            }
        }
    });
}

function initializeChart() {
    // Global bloom timeline chart
    const ctx = document.getElementById('bloomTimelineChart').getContext('2d');
    
    // Generate sample data for the past 30 days
    const dates = [];
    const bloomingData = [];
    const growingData = [];
    const dormantData = [];
    
    for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        dates.push(date.toLocaleDateString());
        
        // Simulate seasonal patterns
        const dayOfYear = date.getMonth() * 30 + date.getDate();
        bloomingData.push(Math.max(0, 50 + 30 * Math.sin((dayOfYear - 80) * 2 * Math.PI / 365) + Math.random() * 20 - 10));
        growingData.push(Math.max(0, 80 - bloomingData[bloomingData.length - 1] + Math.random() * 20 - 10));
        dormantData.push(Math.max(0, 100 - bloomingData[bloomingData.length - 1] - growingData[growingData.length - 1]));
    }
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [
                {
                    label: 'Blooming Locations',
                    data: bloomingData,
                    borderColor: 'rgb(220, 53, 69)',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.1
                },
                {
                    label: 'Growing Locations',
                    data: growingData,
                    borderColor: 'rgb(40, 167, 69)',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.1
                },
                {
                    label: 'Dormant Locations',
                    data: dormantData,
                    borderColor: 'rgb(108, 117, 125)',
                    backgroundColor: 'rgba(108, 117, 125, 0.1)',
                    tension: 0.1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Locations'
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Global Bloom Activity Trends'
                }
            }
        }
    });
}

function getBloomStatusColor(status) {
    switch (status) {
        case 'blooming': return '#dc3545';
        case 'growing': return '#28a745';
        case 'dormant': return '#6c757d';
        default: return '#6c757d';
    }
}

function addToWatchlist(locationId) {
    fetch('api/watchlist.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'add', location_id: locationId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Location added to watchlist!', 'success');
        } else {
            showNotification('Error adding to watchlist: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error adding to watchlist', 'danger');
    });
}

function getNASAImagery(lat, lon) {
    // Open NASA Worldview with the specific coordinates
    const url = `https://worldview.earthdata.nasa.gov/?v=${lon-5},${lat-5},${lon+5},${lat+5}&t=2025-10-04&l=MODIS_Terra_CorrectedReflectance_TrueColor`;
    window.open(url, '_blank');
}
</script>