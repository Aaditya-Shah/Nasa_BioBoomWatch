<?php
/**
 * Data Explorer Page - Browse and analyze vegetation data
 */

require_once 'config/database.php';
require_once 'config/nasa_api.php';

$db = Database::getInstance()->getConnection();

// Get filters
$startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$endDate = $_GET['end_date'] ?? date('Y-m-d');
$locationId = $_GET['location_id'] ?? '';
$bloomStatus = $_GET['bloom_status'] ?? '';

// Build query
$whereConditions = [];
$params = [];

if ($startDate) {
    $whereConditions[] = "vo.observation_date >= ?";
    $params[] = $startDate;
}

if ($endDate) {
    $whereConditions[] = "vo.observation_date <= ?";
    $params[] = $endDate;
}

if ($locationId) {
    $whereConditions[] = "vo.location_id = ?";
    $params[] = $locationId;
}

if ($bloomStatus) {
    $whereConditions[] = "vo.bloom_status = ?";
    $params[] = $bloomStatus;
}

$whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);

// Get observations
$observations = $db->prepare("
    SELECT 
        vo.*,
        l.name as location_name,
        l.country,
        l.latitude,
        l.longitude,
        l.ecosystem_type
    FROM vegetation_observations vo
    JOIN locations l ON vo.location_id = l.id
    {$whereClause}
    ORDER BY vo.observation_date DESC
    LIMIT 100
");
$observations->execute($params);
$data = $observations->fetchAll();

// Get all locations for filter dropdown
$locations = $db->query("SELECT id, name, country FROM locations ORDER BY name")->fetchAll();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0">
                    <i class="fas fa-database me-2"></i>Data Explorer
                </h4>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <input type="hidden" name="page" value="data">
                    
                    <div class="col-md-3">
                        <label class="form-label">Start Date</label>
                        <input type="date" class="form-control" name="start_date" value="<?php echo $startDate; ?>">
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">End Date</label>
                        <input type="date" class="form-control" name="end_date" value="<?php echo $endDate; ?>">
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">Location</label>
                        <select class="form-select" name="location_id">
                            <option value="">All Locations</option>
                            <?php foreach ($locations as $location): ?>
                                <option value="<?php echo $location['id']; ?>" 
                                        <?php echo $locationId == $location['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($location['name'] . ' (' . $location['country'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Bloom Status</label>
                        <select class="form-select" name="bloom_status">
                            <option value="">All Status</option>
                            <option value="blooming" <?php echo $bloomStatus === 'blooming' ? 'selected' : ''; ?>>Blooming</option>
                            <option value="growing" <?php echo $bloomStatus === 'growing' ? 'selected' : ''; ?>>Growing</option>
                            <option value="dormant" <?php echo $bloomStatus === 'dormant' ? 'selected' : ''; ?>>Dormant</option>
                        </select>
                    </div>
                    
                    <div class="col-md-1">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Data Statistics -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body text-center">
                <h3><?php echo count($data); ?></h3>
                <p class="mb-0">Total Observations</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body text-center">
                <h3><?php echo count(array_filter($data, fn($d) => $d['bloom_status'] === 'blooming')); ?></h3>
                <p class="mb-0">Blooming Events</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body text-center">
                <h3><?php echo round(array_sum(array_column($data, 'ndvi_value')) / max(1, count($data)), 3); ?></h3>
                <p class="mb-0">Average NDVI</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body text-center">
                <h3><?php echo count(array_unique(array_column($data, 'location_id'))); ?></h3>
                <p class="mb-0">Unique Locations</p>
            </div>
        </div>
    </div>
</div>

<!-- Data Visualization -->
<div class="row mb-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-area me-2"></i>NDVI Trends Over Time
                </h5>
            </div>
            <div class="card-body">
                <canvas id="ndviTrendChart" height="100"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-pie me-2"></i>Bloom Status Distribution
                </h5>
            </div>
            <div class="card-body">
                <canvas id="bloomStatusChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Data Table -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-table me-2"></i>Observation Data
                </h5>
                <div>
                    <button class="btn btn-outline-success btn-sm" onclick="exportToCSV()">
                        <i class="fas fa-download me-1"></i>Export CSV
                    </button>
                    <button class="btn btn-outline-primary btn-sm" onclick="refreshNASAData()">
                        <i class="fas fa-sync me-1"></i>Refresh NASA Data
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTable">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Location</th>
                                <th>Country</th>
                                <th>Ecosystem</th>
                                <th>NDVI</th>
                                <th>Status</th>
                                <th>Intensity</th>
                                <th>Confidence</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data as $obs): ?>
                                <tr>
                                    <td><?php echo formatDate($obs['observation_date']); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($obs['location_name']); ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            <?php echo $obs['latitude']; ?>, <?php echo $obs['longitude']; ?>
                                        </small>
                                    </td>
                                    <td><?php echo htmlspecialchars($obs['country']); ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark">
                                            <?php echo htmlspecialchars($obs['ecosystem_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $obs['ndvi_value'] > 0.6 ? 'success' : ($obs['ndvi_value'] > 0.4 ? 'warning' : 'secondary'); ?>">
                                            <?php echo $obs['ndvi_value']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge" style="background-color: <?php echo getBloomStatusColor($obs['bloom_status']); ?>">
                                            <?php echo ucfirst($obs['bloom_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar" 
                                                 style="width: <?php echo $obs['bloom_intensity']; ?>%; background-color: <?php echo getBloomIntensityColor($obs['bloom_intensity']); ?>">
                                                <?php echo $obs['bloom_intensity']; ?>%
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php echo round($obs['confidence_score'] * 100); ?>%
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" 
                                                    onclick="viewLocationHistory(<?php echo $obs['location_id']; ?>)"
                                                    title="View History">
                                                <i class="fas fa-history"></i>
                                            </button>
                                            <button class="btn btn-outline-success" 
                                                    onclick="getNASAImagery(<?php echo $obs['latitude']; ?>, <?php echo $obs['longitude']; ?>)"
                                                    title="NASA Imagery">
                                                <i class="fas fa-satellite"></i>
                                            </button>
                                            <button class="btn btn-outline-danger" 
                                                    onclick="addToWatchlist(<?php echo $obs['location_id']; ?>)"
                                                    title="Add to Watchlist">
                                                <i class="fas fa-heart"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if (empty($data)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No data found</h5>
                        <p class="text-muted">Try adjusting your filters to see more results.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Location History Modal -->
<div class="modal fade" id="locationHistoryModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-history me-2"></i>Location History
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="locationHistoryContent">
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
});

function initializeCharts() {
    // NDVI Trend Chart
    const trendCtx = document.getElementById('ndviTrendChart').getContext('2d');
    const observationData = <?php echo json_encode($data); ?>;
    
    // Group data by date
    const dateGroups = {};
    observationData.forEach(obs => {
        const date = obs.observation_date;
        if (!dateGroups[date]) {
            dateGroups[date] = [];
        }
        dateGroups[date].push(parseFloat(obs.ndvi_value));
    });
    
    const dates = Object.keys(dateGroups).sort();
    const avgNDVI = dates.map(date => {
        const values = dateGroups[date];
        return values.reduce((sum, val) => sum + val, 0) / values.length;
    });
    
    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: dates.map(date => new Date(date).toLocaleDateString()),
            datasets: [{
                label: 'Average NDVI',
                data: avgNDVI,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1,
                    title: {
                        display: true,
                        text: 'NDVI Value'
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Vegetation Index Trends'
                }
            }
        }
    });
    
    // Bloom Status Pie Chart
    const statusCtx = document.getElementById('bloomStatusChart').getContext('2d');
    const statusCounts = {};
    observationData.forEach(obs => {
        statusCounts[obs.bloom_status] = (statusCounts[obs.bloom_status] || 0) + 1;
    });
    
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(statusCounts).map(status => status.charAt(0).toUpperCase() + status.slice(1)),
            datasets: [{
                data: Object.values(statusCounts),
                backgroundColor: [
                    '#dc3545', // blooming - red
                    '#28a745', // growing - green
                    '#6c757d'  // dormant - gray
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function exportToCSV() {
    const table = document.getElementById('dataTable');
    const rows = Array.from(table.querySelectorAll('tr'));
    
    const csvContent = rows.map(row => {
        const cells = Array.from(row.querySelectorAll('th, td'));
        return cells.map(cell => {
            // Clean cell content
            let content = cell.textContent.trim();
            // Remove action buttons
            if (cell.querySelector('.btn-group')) {
                content = '';
            }
            // Escape quotes and wrap in quotes if contains comma
            if (content.includes(',') || content.includes('"') || content.includes('\n')) {
                content = '"' + content.replace(/"/g, '""') + '"';
            }
            return content;
        }).join(',');
    }).join('\n');
    
    // Create and download CSV file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `bloomwatch_data_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

function refreshNASAData() {
    showNotification('Refreshing NASA data...', 'info');
    
    fetch('api/refresh_data.php', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('NASA data refreshed successfully!', 'success');
            setTimeout(() => location.reload(), 2000);
        } else {
            showNotification('Error refreshing data: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error refreshing NASA data', 'danger');
    });
}

function viewLocationHistory(locationId) {
    $('#locationHistoryModal').modal('show');
    
    fetch(`api/location.php?id=${locationId}&history=true`)
        .then(response => response.json())
        .then(data => {
            const content = document.getElementById('locationHistoryContent');
            
            if (data.error) {
                content.innerHTML = '<div class="alert alert-danger">Error loading location history.</div>';
                return;
            }
            
            let html = `
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h5>${data.location.name}</h5>
                        <p class="text-muted">
                            ${data.location.country}, ${data.location.region}<br>
                            ${data.location.ecosystem_type}
                        </p>
                    </div>
                    <div class="col-md-6">
                        <canvas id="historyChart" height="200"></canvas>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>NDVI</th>
                                <th>Status</th>
                                <th>Intensity</th>
                                <th>Confidence</th>
                            </tr>
                        </thead>
                        <tbody>
            `;
            
            data.history.forEach(obs => {
                html += `
                    <tr>
                        <td>${new Date(obs.observation_date).toLocaleDateString()}</td>
                        <td>${obs.ndvi_value}</td>
                        <td><span class="badge" style="background-color: ${getBloomStatusColor(obs.bloom_status)}">${obs.bloom_status}</span></td>
                        <td>${obs.bloom_intensity}%</td>
                        <td>${Math.round(obs.confidence_score * 100)}%</td>
                    </tr>
                `;
            });
            
            html += `
                        </tbody>
                    </table>
                </div>
            `;
            
            content.innerHTML = html;
            
            // Create history chart
            const ctx = document.getElementById('historyChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.history.map(h => new Date(h.observation_date).toLocaleDateString()),
                    datasets: [{
                        label: 'NDVI',
                        data: data.history.map(h => h.ndvi_value),
                        borderColor: 'rgb(75, 192, 192)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 1
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('locationHistoryContent').innerHTML = 
                '<div class="alert alert-danger">Error loading location history.</div>';
        });
}

function getNASAImagery(lat, lon) {
    const url = `https://worldview.earthdata.nasa.gov/?v=${lon-5},${lat-5},${lon+5},${lat+5}&t=2025-10-04&l=MODIS_Terra_CorrectedReflectance_TrueColor`;
    window.open(url, '_blank');
}

function addToWatchlist(locationId) {
    fetch('api/watchlist.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'add', location_id: locationId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Location added to watchlist!', 'success');
        } else {
            showNotification('Error adding to watchlist: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error adding to watchlist', 'danger');
    });
}

function getBloomStatusColor(status) {
    switch (status) {
        case 'blooming': return '#dc3545';
        case 'growing': return '#28a745';
        case 'dormant': return '#6c757d';
        default: return '#6c757d';
    }
}
</script>