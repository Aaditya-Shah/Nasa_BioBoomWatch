<?php
/**
 * Watchlist API endpoint
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/database.php';
require_once '../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$db = Database::getInstance()->getConnection();

switch ($method) {
    case 'GET':
        // Get user's watchlist
        $watchlist = getUserWatchlist();
        echo json_encode($watchlist);
        break;
        
    case 'POST':
        // Add/remove from watchlist
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['action'], $input['location_id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing required fields: action, location_id']);
            exit();
        }
        
        $action = $input['action'];
        $locationId = intval($input['location_id']);
        
        if ($action === 'add') {
            $result = addToWatchlist($locationId);
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Location added to watchlist']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to add location to watchlist']);
            }
        } elseif ($action === 'remove') {
            $result = removeFromWatchlist($locationId);
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Location removed from watchlist']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to remove location from watchlist']);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action. Use "add" or "remove"']);
        }
        break;
        
    case 'DELETE':
        // Remove from watchlist (alternative method)
        $locationId = intval($_GET['location_id'] ?? 0);
        
        if (!$locationId) {
            http_response_code(400);
            echo json_encode(['error' => 'location_id is required']);
            exit();
        }
        
        $result = removeFromWatchlist($locationId);
        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Location removed from watchlist']);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Failed to remove location from watchlist']);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>