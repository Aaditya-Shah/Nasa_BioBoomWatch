<?php
/**
 * Refresh NASA data endpoint
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

require_once '../config/database.php';
require_once '../config/nasa_api.php';
require_once '../includes/functions.php';

$db = Database::getInstance()->getConnection();

try {
    // Get all locations
    $locations = $db->query("SELECT * FROM locations")->fetchAll();
    
    $updated = 0;
    $errors = [];
    
    foreach ($locations as $location) {
        try {
            // Get vegetation data from NASA (simulated)
            $vegetationData = NasaAPI::getVegetationIndex(
                $location['latitude'],
                $location['longitude'],
                date('Y-m-d', strtotime('-7 days')),
                date('Y-m-d')
            );
            
            if ($vegetationData && !empty($vegetationData)) {
                // Insert new observations
                $stmt = $db->prepare("
                    INSERT OR REPLACE INTO vegetation_observations 
                    (location_id, observation_date, ndvi_value, bloom_status, bloom_intensity, confidence_score, data_source) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                
                foreach ($vegetationData as $data) {
                    $bloomStatus = 'dormant';
                    if ($data['ndvi'] > 0.6) {
                        $bloomStatus = 'blooming';
                    } elseif ($data['ndvi'] > 0.4) {
                        $bloomStatus = 'growing';
                    }
                    
                    $bloomIntensity = min(100, max(0, $data['bloom_probability']));
                    
                    $stmt->execute([
                        $location['id'],
                        $data['date'],
                        $data['ndvi'],
                        $bloomStatus,
                        $bloomIntensity,
                        0.85, // Confidence score
                        'NASA_REFRESH'
                    ]);
                }
                
                $updated++;
            }
        } catch (Exception $e) {
            $errors[] = "Location {$location['name']}: " . $e->getMessage();
            error_log("NASA data refresh error for location {$location['id']}: " . $e->getMessage());
        }
    }
    
    // Clean old cache
    cleanExpiredCache();
    
    // Get some NASA APOD for good measure
    try {
        $apod = NasaAPI::getAPOD();
        if ($apod) {
            cacheAPIResponse('apod_today', $apod, 86400); // Cache for 24 hours
        }
    } catch (Exception $e) {
        $errors[] = "APOD fetch error: " . $e->getMessage();
    }
    
    $response = [
        'success' => true,
        'message' => "Successfully refreshed data for {$updated} locations",
        'updated_locations' => $updated,
        'total_locations' => count($locations),
        'timestamp' => date('c')
    ];
    
    if (!empty($errors)) {
        $response['warnings'] = $errors;
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log("NASA data refresh error: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to refresh NASA data',
        'error' => $e->getMessage()
    ]);
}
?>