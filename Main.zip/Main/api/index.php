<?php
/**
 * API Index - Main API router
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/database.php';
require_once '../config/nasa_api.php';
require_once '../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = $_SERVER['PATH_INFO'] ?? '/';
$path = trim($path, '/');

// Basic routing
switch ($path) {
    case '':
    case 'status':
        handleAPIStatus();
        break;
    case 'locations':
        handleLocations($method);
        break;
    case 'observations':
        handleObservations($method);
        break;
    case 'predictions':
        handlePredictions($method);
        break;
    case 'nasa':
        handleNASAData($method);
        break;
    default:
        http_response_code(404);
        echo json_encode(['error' => 'Endpoint not found']);
        break;
}

function handleAPIStatus() {
    $status = [
        'status' => 'online',
        'version' => '1.0.0',
        'timestamp' => date('c'),
        'nasa_api_key' => substr(NasaAPI::API_KEY, 0, 8) . '...',
        'endpoints' => [
            '/api/status' => 'API status',
            '/api/locations' => 'Location management',
            '/api/observations' => 'Vegetation observations',
            '/api/predictions' => 'Bloom predictions',
            '/api/nasa' => 'NASA data proxy'
        ]
    ];
    
    echo json_encode($status, JSON_PRETTY_PRINT);
}

function handleLocations($method) {
    $db = Database::getInstance()->getConnection();
    
    switch ($method) {
        case 'GET':
            $locations = $db->query("
                SELECT l.*, 
                       vo.bloom_status, 
                       vo.bloom_intensity, 
                       vo.ndvi_value,
                       vo.observation_date
                FROM locations l
                LEFT JOIN vegetation_observations vo ON l.id = vo.location_id
                WHERE vo.id IN (
                    SELECT MAX(id) 
                    FROM vegetation_observations 
                    GROUP BY location_id
                ) OR vo.id IS NULL
                ORDER BY l.name
            ")->fetchAll();
            
            echo json_encode($locations);
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input || !isset($input['name'], $input['latitude'], $input['longitude'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Missing required fields']);
                return;
            }
            
            $stmt = $db->prepare("
                INSERT INTO locations (name, latitude, longitude, country, region, ecosystem_type) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $input['name'],
                $input['latitude'],
                $input['longitude'],
                $input['country'] ?? null,
                $input['region'] ?? null,
                $input['ecosystem_type'] ?? null
            ]);
            
            if ($result) {
                echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Failed to create location']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
            break;
    }
}

function handleObservations($method) {
    $db = Database::getInstance()->getConnection();
    
    switch ($method) {
        case 'GET':
            $limit = intval($_GET['limit'] ?? 50);
            $offset = intval($_GET['offset'] ?? 0);
            $locationId = $_GET['location_id'] ?? null;
            $startDate = $_GET['start_date'] ?? null;
            $endDate = $_GET['end_date'] ?? null;
            
            $whereConditions = [];
            $params = [];
            
            if ($locationId) {
                $whereConditions[] = "vo.location_id = ?";
                $params[] = $locationId;
            }
            
            if ($startDate) {
                $whereConditions[] = "vo.observation_date >= ?";
                $params[] = $startDate;
            }
            
            if ($endDate) {
                $whereConditions[] = "vo.observation_date <= ?";
                $params[] = $endDate;
            }
            
            $whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);
            
            $stmt = $db->prepare("
                SELECT vo.*, l.name as location_name, l.country, l.latitude, l.longitude
                FROM vegetation_observations vo
                JOIN locations l ON vo.location_id = l.id
                {$whereClause}
                ORDER BY vo.observation_date DESC
                LIMIT ? OFFSET ?
            ");
            
            $params[] = $limit;
            $params[] = $offset;
            
            $stmt->execute($params);
            $observations = $stmt->fetchAll();
            
            echo json_encode($observations);
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input || !isset($input['location_id'], $input['observation_date'], $input['ndvi_value'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Missing required fields']);
                return;
            }
            
            $stmt = $db->prepare("
                INSERT INTO vegetation_observations 
                (location_id, observation_date, ndvi_value, bloom_status, bloom_intensity, confidence_score, data_source) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $input['location_id'],
                $input['observation_date'],
                $input['ndvi_value'],
                $input['bloom_status'] ?? 'unknown',
                $input['bloom_intensity'] ?? 0,
                $input['confidence_score'] ?? 0.8,
                $input['data_source'] ?? 'API'
            ]);
            
            if ($result) {
                echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Failed to create observation']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
            break;
    }
}

function handlePredictions($method) {
    if ($method !== 'GET') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        return;
    }
    
    $locationId = $_GET['location_id'] ?? null;
    $days = intval($_GET['days'] ?? 7);
    
    if (!$locationId) {
        http_response_code(400);
        echo json_encode(['error' => 'location_id is required']);
        return;
    }
    
    $db = Database::getInstance()->getConnection();
    
    // Get location info
    $location = $db->prepare("SELECT * FROM locations WHERE id = ?");
    $location->execute([$locationId]);
    $locationData = $location->fetch();
    
    if (!$locationData) {
        http_response_code(404);
        echo json_encode(['error' => 'Location not found']);
        return;
    }
    
    // Get recent observations for this location
    $recentObs = $db->prepare("
        SELECT * FROM vegetation_observations 
        WHERE location_id = ? 
        ORDER BY observation_date DESC 
        LIMIT 10
    ");
    $recentObs->execute([$locationId]);
    $history = $recentObs->fetchAll();
    
    // Generate predictions
    $predictions = [];
    $currentSeason = getCurrentSeason(null, $locationData['latitude'] > 0 ? 'north' : 'south');
    
    for ($i = 1; $i <= $days; $i++) {
        $date = new Date();
        $date->setDate($date->getDate() + $i);
        
        // Simple prediction algorithm
        $recentNDVI = !empty($history) ? array_column(array_slice($history, 0, 4), 'ndvi_value') : [0.4];
        $avgNDVI = array_sum($recentNDVI) / count($recentNDVI);
        
        $probability = predictBloomProbability($recentNDVI, $currentSeason, $locationData);
        
        $predictions[] = [
            'date' => $date->format('Y-m-d'),
            'bloom_probability' => $probability,
            'predicted_ndvi' => min(1.0, max(0.0, $avgNDVI + (rand(-10, 10) / 100))),
            'confidence' => min(95, 60 + ($probability / 100) * 35),
            'weather_factor' => rand(85, 100) / 100
        ];
    }
    
    echo json_encode([
        'location' => $locationData,
        'predictions' => $predictions,
        'model_info' => [
            'version' => '1.0',
            'last_trained' => '2025-10-04',
            'accuracy' => 87.3
        ]
    ]);
}

function handleNASAData($method) {
    if ($method !== 'GET') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        return;
    }
    
    $endpoint = $_GET['endpoint'] ?? '';
    $lat = $_GET['lat'] ?? null;
    $lon = $_GET['lon'] ?? null;
    $date = $_GET['date'] ?? null;
    
    switch ($endpoint) {
        case 'apod':
            $data = NasaAPI::getAPOD($date);
            break;
            
        case 'earth_imagery':
            if (!$lat || !$lon) {
                http_response_code(400);
                echo json_encode(['error' => 'lat and lon are required for earth imagery']);
                return;
            }
            $data = NasaAPI::getEarthImagery($lat, $lon, $date);
            break;
            
        case 'earth_assets':
            if (!$lat || !$lon) {
                http_response_code(400);
                echo json_encode(['error' => 'lat and lon are required for earth assets']);
                return;
            }
            $data = NasaAPI::getEarthAssets($lat, $lon);
            break;
            
        case 'events':
            $data = NasaAPI::getNaturalEvents();
            break;
            
        case 'epic':
            $data = NasaAPI::getEPICImages($date);
            break;
            
        case 'vegetation':
            if (!$lat || !$lon) {
                http_response_code(400);
                echo json_encode(['error' => 'lat and lon are required for vegetation data']);
                return;
            }
            $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $endDate = $_GET['end_date'] ?? date('Y-m-d');
            $data = NasaAPI::getVegetationIndex($lat, $lon, $startDate, $endDate);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid endpoint. Available: apod, earth_imagery, earth_assets, events, epic, vegetation']);
            return;
    }
    
    if ($data === false) {
        http_response_code(502);
        echo json_encode(['error' => 'NASA API request failed']);
        return;
    }
    
    echo json_encode($data);
}
?>