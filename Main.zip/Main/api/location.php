<?php
/**
 * Location details API endpoint
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

require_once '../config/database.php';
require_once '../includes/functions.php';

$locationId = intval($_GET['id'] ?? 0);
$includeHistory = isset($_GET['history']) && $_GET['history'] === 'true';

if (!$locationId) {
    http_response_code(400);
    echo json_encode(['error' => 'location_id is required']);
    exit();
}

$db = Database::getInstance()->getConnection();

// Get location details
$locationStmt = $db->prepare("SELECT * FROM locations WHERE id = ?");
$locationStmt->execute([$locationId]);
$location = $locationStmt->fetch();

if (!$location) {
    http_response_code(404);
    echo json_encode(['error' => 'Location not found']);
    exit();
}

$response = ['location' => $location];

if ($includeHistory) {
    // Get observation history
    $historyStmt = $db->prepare("
        SELECT * FROM vegetation_observations 
        WHERE location_id = ? 
        ORDER BY observation_date DESC 
        LIMIT 50
    ");
    $historyStmt->execute([$locationId]);
    $history = $historyStmt->fetchAll();
    
    $response['history'] = $history;
    
    // Get statistics
    $statsStmt = $db->prepare("
        SELECT 
            AVG(ndvi_value) as avg_ndvi,
            MAX(ndvi_value) as max_ndvi,
            MIN(ndvi_value) as min_ndvi,
            AVG(bloom_intensity) as avg_intensity,
            COUNT(*) as total_observations,
            COUNT(CASE WHEN bloom_status = 'blooming' THEN 1 END) as blooming_count
        FROM vegetation_observations 
        WHERE location_id = ?
    ");
    $statsStmt->execute([$locationId]);
    $stats = $statsStmt->fetch();
    
    $response['statistics'] = $stats;
    
    // Generate timeline data for chart
    $timeline = [];
    foreach ($history as $obs) {
        $timeline[] = [
            'date' => $obs['observation_date'],
            'ndvi' => floatval($obs['ndvi_value']),
            'intensity' => intval($obs['bloom_intensity']),
            'status' => $obs['bloom_status']
        ];
    }
    
    $response['timeline'] = array_reverse($timeline); // Oldest first for chart
}

// Get current status
$currentStmt = $db->prepare("
    SELECT * FROM vegetation_observations 
    WHERE location_id = ? 
    ORDER BY observation_date DESC 
    LIMIT 1
");
$currentStmt->execute([$locationId]);
$current = $currentStmt->fetch();

if ($current) {
    $response['current_status'] = $current;
}

// Check if in user's watchlist
$response['in_watchlist'] = isInWatchlist($locationId);

echo json_encode($response);
?>