# BloomWatch Application Structure

This document provides an overview of the BloomWatch application structure and how to navigate the codebase.

## Directory Structure

```
bloomwatch/
├── index.php                 # Main entry point and router
├── README.md                 # Project documentation
├── 
├── config/                   # Configuration files
│   ├── database.php         # SQLite database setup and management
│   └── nasa_api.php         # NASA API configuration and wrapper functions
├── 
├── pages/                    # Main application pages
│   ├── dashboard.php        # Dashboard with overview and statistics
│   ├── map.php              # Interactive global map interface
│   ├── data.php             # Data explorer and browser
│   └── analytics.php        # Advanced analytics and predictions
├── 
├── api/                      # RESTful API endpoints
│   ├── index.php            # Main API router
│   ├── watchlist.php        # Watchlist management API
│   ├── location.php         # Location details API
│   └── refresh_data.php     # NASA data refresh API
├── 
├── templates/                # HTML templates
│   ├── header.php           # Common header with navigation
│   └── footer.php           # Common footer with scripts
├── 
├── includes/                 # Helper functions and utilities
│   └── functions.php        # Common utility functions
├── 
├── assets/                   # Static assets
│   ├── css/
│   │   └── style.css        # Custom CSS styles
│   ├── js/
│   │   └── main.js          # Main JavaScript functionality
│   └── images/              # Image assets (if any)
├── 
└── data/                     # Database storage (auto-created)
    └── bloomwatch.db        # SQLite database file
```

## File Descriptions

### Core Files

- **index.php**: Main entry point that handles routing and includes appropriate pages
- **README.md**: Comprehensive project documentation

### Configuration (`config/`)

- **database.php**: Database class with SQLite setup, table creation, and sample data
- **nasa_api.php**: NASA API wrapper class with all endpoint methods and rate limiting

### Pages (`pages/`)

- **dashboard.php**: Main dashboard with statistics, recent activity, and APOD
- **map.php**: Interactive Leaflet map with markers, filters, and location details
- **data.php**: Data exploration interface with filtering, charts, and export
- **analytics.php**: Advanced analytics with predictions and correlations

### API (`api/`)

- **index.php**: RESTful API router handling locations, observations, predictions, NASA data
- **watchlist.php**: Watchlist management (add/remove locations)
- **location.php**: Location details with history and statistics
- **refresh_data.php**: Refresh NASA data and update database

### Templates (`templates/`)

- **header.php**: Common HTML header with navigation, CSS includes, and meta tags
- **footer.php**: Common HTML footer with JavaScript includes and modals

### Utilities (`includes/`)

- **functions.php**: Helper functions for formatting, calculations, caching, and user management

### Assets (`assets/`)

- **css/style.css**: Custom CSS with gradients, responsive design, and component styles
- **js/main.js**: JavaScript for API calls, UI interactions, and application logic

## Key Features by File

### Database Schema (database.php)
- `locations`: Monitoring locations worldwide
- `vegetation_observations`: NDVI and bloom data
- `bloom_events`: Specific blooming events
- `api_cache`: API response caching
- `user_watchlist`: User favorite locations

### NASA API Integration (nasa_api.php)
- APOD (Astronomy Picture of the Day)
- Earth Imagery (Landsat)
- Earth Assets
- EONET Natural Events
- EPIC Earth Images
- Vegetation Index (simulated MODIS data)

### Interactive Features
- Real-time map with bloom markers
- Filterable data tables
- Interactive charts and visualizations
- Bloom prediction algorithms
- Personal watchlist management
- Data export functionality

## Getting Started

1. **Setup**: Place files in web server directory
2. **Database**: SQLite database auto-creates on first run
3. **API Key**: NASA API key is pre-configured
4. **Access**: Navigate to index.php in browser

## Development Notes

- Built with PHP 8.0+ and modern web standards
- Uses SQLite for simplicity (no database server required)
- Responsive design works on all devices
- NASA API integration with error handling and caching
- Modular structure for easy maintenance and expansion

## Customization

- Modify `config/nasa_api.php` to change API endpoints or keys
- Update `assets/css/style.css` for visual customization
- Extend `includes/functions.php` for additional utility functions
- Add new pages in `pages/` directory and update routing in `index.php`